<?php

/**
 *	LITHIUM TEMPLATE
 *	By Xemah | https://xemah.com
 *  Owned by Coldfire | https://coldfiredzn.com
 *
**/

/*  
 *  LEAKED BY REALNOTSOUND
 *  CREDITS TO MY GOOD FRIEND 'IHateFrance332' for helping out!
 *  Do not touch the above or the leak will not work!
 */
?>


<div class="lithium-panel-content">
	<div class="lithium-panel-header">
		<a href="#lithium-panel-menu">
			<i class="fas fa-angle-left"></i>
		</a>
		<div class="lithium-panel-title">
			Update
		</div>
	</div>
	<div class="lithium-panel-body">
		<div class="lithium-update">
			<div class="lithium-update-status">
				<?php if ($lithium_version == "error") { ?>
					<span class="text-danger">
						<i class="fas fa-exclamation-circle"></i>
					</span>
					Unknown error occured!
				<?php } else if ($lithium_version !== LithiumTemplate::$VERSION) { ?>
					<span class="text-warning">
						<i class="fas fa-exclamation-circle"></i>
					</span>
					Update available!
				<?php } else if ($lithium_version == LithiumTemplate::$VERSION) { ?>
					<span class="text-success">
						<i class="fas fa-check-circle"></i>
					</span>
					Up to date!
				<?php } ?>
			</div>
			<div class="lithium-update-section">
				<div class="lithium-update-section-description">
					<dl>
						<dt>Current Version</dt>
						<dd><?php echo LithiumTemplate::$VERSION; ?></dd>
					</dl>
					<dl>
						<dt>Latest Version</dt>
						<?php if (isset($lithium_version)) { ?>
							<dd><?php echo $lithium_version; ?></dd>
						<?php } else { ?>
							<dd>??</dd>
						<?php } ?>
					</dl>
				</div>
			</div>
			<?php if ($lithium_version !== LithiumTemplate::$VERSION)  { ?>
				<div class="lithium-update-section">
					<a class="lithium-button lithium-button-download" href="https://builtbybit.com/resources/19734/updates" target="_blank">Download Update</a>
				</div>
				<div class="lithium-update-section">
					<div class="lithium-update-section-title">
						Instructions:
					</div>
					<div class="lithium-update-section-description">
						<ul>
							<li>Download the latest version of the Lithium template.</li>
							<li>Upload the files and make sure it merges with the existing files.</li>
							<li>If you've modified any source file, make sure to back it up first before updating.</li>
						</ul>
					</div>
				</div>
			<?php } ?>
		</div>
	</div>
</div>