/**
 *	LITHIUM TEMPLATE
 *	By Xemah | https://xemah.com
 *
**/

var lastAlertIds = [];
var lastMessageIds = [];

async function fetchAlerts() {

	const rawData = await fetch(buildUrl('/queries/alerts'));
	const data = await rawData.json();

	data.alerts.reverse();
	return data.alerts;

}

async function fetchMessages() {

	const rawData = await fetch(buildUrl('/queries/pms'));
	const data = await rawData.json();

	data.pms.reverse();
	return data.pms;

}

function updateAlerts(alerts) {

	let alertsList = '';

	if (alerts.length > 0) {
		document.querySelector('#button-alerts').classList.add('inc');
		for (const alert of alerts) {
			alertsList += `<li>
				<a href="${buildUrl('/user/alerts/', `view=${alert.id}`)}" class="dropdown-item">${alert.content_short}</a>
			</li>`;
		}
	} else {
		document.querySelector('#button-alerts').classList.remove('inc');
		alertsList = `<li>
			<span class="dropdown-item">${locale.noAlerts}</span>
		</li>`;
	}

	document.querySelector('#list-alerts').innerHTML = alertsList;

}

function updateMessages(messages) {

	let messagesList = '';

	if (messages.length > 0) {
		document.querySelector('#button-pms').classList.add('inc');
		for (const message of messages) {
			messagesList += `<li>
				<a href="${buildUrl('/user/messaging/', `action=view&message=${message.id}`)}" class="dropdown-item">${message.title}</a>
			</li>`;
		}
	} else {
		document.querySelector('#button-pms').classList.remove('inc');
		messagesList = `<li>
			<span class="dropdown-item">${locale.noMessages}</span>
		</li>`;
	}

	document.querySelector('#list-pms').innerHTML = messagesList;

}

function notifyAlerts(alerts) {

	if (alerts.length == 0) {
		return;
	}

	if (document.referrer.indexOf(location.protocol + "//" + location.host) === 0) {
		return;
	}

	if (alerts.length == 1) {
		toastr.info(locale.newAlert1.replace('{{count}}', alerts.length), null, {
			onclick: () => redirect(buildUrl('/user/alerts'))
		});
	} else {
		toastr.info(locale.newAlertsX.replace('{{count}}', alerts.length), null, {
			onclick: () => redirect(buildUrl('/user/alerts'))
		});
	}

}

function notifyMessages(messages) {

	if (messages.length == 0) {
		return;
	}

	if (document.referrer.indexOf(location.protocol + "//" + location.host) === 0) {
		return;
	}

	if (messages.length == 1) {
		toastr.info(locale.newMessage1.replace('{{count}}', messages.length), null, {
			onclick: () => redirect(buildUrl('/user/messaging'))
		});
	} else {
		toastr.info(locale.newMessagesX.replace('{{count}}', messages.length), null, {
			onclick: () => redirect(buildUrl('/user/messaging'))
		});
	}

}

async function updateAndNotifyAlertsAndMessages() {

	const alerts = await fetchAlerts();
	//if (!alerts.every((alert) => lastAlertIds.includes(alert.id))) {
		updateAlerts(alerts);
		notifyAlerts(alerts);

		lastAlertIds = alerts.map((alert) => alert.id);
		sessionStorage.alerts = btoa(JSON.stringify(alerts));
	//}

	const messages = await fetchMessages();
	//if (!messages.every((message) => lastMessageIds.includes(message.id))) {
		updateMessages(messages);
		notifyMessages(messages);

		lastMessageIds = messages.map((message) => message.id);
		sessionStorage.messages = btoa(JSON.stringify(messages));
	//}

}

const userbar = document.querySelector('.navbar-user');
if (userbar) {
	updateAndNotifyAlertsAndMessages();
	setInterval(updateAndNotifyAlertsAndMessages, 10000);
}