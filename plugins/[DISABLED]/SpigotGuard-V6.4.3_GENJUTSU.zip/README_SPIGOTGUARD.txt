Hello! Thank you for using our product!

Please open ticket on our discord: https://mc-protection.eu/discord to get SpigotGuard role and license key.

We recommend our AntiBot and AntiNullPing/AntiCrasher for BungeeCord: Aegis. You can buy it at https://mc-protection.eu/products too.

Our SpigotGuard and Aegis are used by 1,000 customers! Including servers with 5,000 people.
My own server: hubplay.pl (~500 players - using Aegis and SpigotGuard)