package com.arkflame.flamequests.tasks;

public class ExampleTask implements Runnable {
    @Override
    public void run() {
        // TODO: Implement logic
    }
}