package com.arkflame.flamequests.players;

import com.arkflame.flamequests.enums.QuestStatus;
import com.arkflame.flamequests.quests.Quest;

public class QuestProgress {
    private QuestStatus status;
    private Quest quest;
    // TODO: Store progress here
}
