# FlameQuests

Daily quests systems for any kind of server wishing to reward their players for accomplishing objectives.
