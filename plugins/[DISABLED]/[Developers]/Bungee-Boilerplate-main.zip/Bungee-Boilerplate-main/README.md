# BungeeCord Boilerplate

Sample project to create Plugins for BungeeCord.
