package net.tonimatasmc.perworldplugins.listener;

import org.bukkit.plugin.RegisteredListener;

public interface Listener {
    RegisteredListener getDelegate();
}

