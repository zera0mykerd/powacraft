Keep your chunks loaded! 
ChunkLoader is an easy to use plugin to keep your chunks loaded!
