# MKUnion
A plugin for management servers

- Clear chat client-side/server-side
- Fix many bugs for prison mine
- Fix enderpearl bugs
- Add delay enderpearl
- Antibypass essentials sub-commands
- Command for no-clip fix
- Stats command for all vanilla statistics
- Mklag command for server lag monitoring
- Autokill arrows on terrain
- Simple setspawn and spawn teleport
- Autofix log4j RCE exploit (packet[Protocollib required] and chat mode)
- On join spawn firework
- On kill firework
- On kill ghast scream and spawn thunder
- Autospawn + autoclean potion and inventory
- Vault protection
- Togglebuild for operators (enable and disable build) prevent accidentally break
- Fix Bow punch
