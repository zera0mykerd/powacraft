![Header](https://i.imgur.com/RKgOPjp.png)
![Dependencies](https://i.imgur.com/zbuyRh1.png)

**Mandatory:**  
- [Jedis Wrapper](https://www.spigotmc.org/resources/jedis-wrapper.101260/)  
- [Milkshake Bukkit](https://www.spigotmc.org/resources/milkshake-bukkit-mongodb-odm.101518/)  

**Optional:**  
- [Interface Maker](https://www.spigotmc.org/resources/interfacemaker.101353/) (To display party info in a GUI)

![Features](https://i.imgur.com/Jg1kQed.png)
![ScreenShots](https://i.imgur.com/c0oyN1w.png)
