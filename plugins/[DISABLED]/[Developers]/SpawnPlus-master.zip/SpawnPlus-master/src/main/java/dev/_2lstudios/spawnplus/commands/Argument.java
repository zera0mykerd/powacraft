package dev._2lstudios.spawnplus.commands;

public enum Argument {
  STRING, LARGE_STRING, INT, BOOL, ONLINE_PLAYER, WORLD
}