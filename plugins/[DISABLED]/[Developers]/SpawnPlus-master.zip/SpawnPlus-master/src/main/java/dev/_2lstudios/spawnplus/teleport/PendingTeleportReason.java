package dev._2lstudios.spawnplus.teleport;

public enum PendingTeleportReason {
    BACK, WARP, HOME, SPAWN, PLAYER, VOID, WORLD, UNKNOWN
}
