package dev._2lstudios.spawnplus.portals;

public enum PortalActionType {
    PLAYER, SERVER, CONSOLE, SOUND, TELL
}
