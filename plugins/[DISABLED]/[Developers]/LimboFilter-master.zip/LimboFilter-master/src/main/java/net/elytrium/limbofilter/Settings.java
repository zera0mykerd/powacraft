/*
 * Copyright (C) 2021 - 2022 Elytrium
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package net.elytrium.limbofilter;

import java.util.List;
import java.util.Map;
import net.elytrium.java.commons.config.YamlConfig;

public class Settings extends YamlConfig {

  @Ignore
  public static final Settings IMP = new Settings();

  @Final
  public String VERSION = BuildConstants.FILTER_VERSION;

  @Comment({
      "Available serializers:",
      "LEGACY_AMPERSAND - \"&c&lExample &c&9Text\".",
      "LEGACY_SECTION - \"§c§lExample §c§9Text\".",
      "MINIMESSAGE - \"<bold><red>Example</red> <blue>Text</blue></bold>\". (https://webui.adventure.kyori.net/)",
      "GSON - \"[{\"text\":\"Example\",\"bold\":true,\"color\":\"red\"},{\"text\":\" \",\"bold\":true},{\"text\":\"Text\",\"bold\":true,\"color\":\"blue\"}]\". (https://minecraft.tools/en/json_text.php/)",
      "GSON_COLOR_DOWNSAMPLING - Same as GSON, but uses downsampling."
  })
  public String SERIALIZER = "LEGACY_AMPERSAND";
  public String PREFIX = "LimboFilter &6>>&f";

  @Create
  public MAIN MAIN;

  @Comment("Don't use \\n, use {NL} for new line, and {PRFX} for prefix.")
  public static class MAIN {

    @Comment("Check if player's Minecraft client sends the network packet with the settings.")
    public boolean CHECK_CLIENT_SETTINGS = true;
    @Comment("Check if player's Minecraft client has a brand.")
    public boolean CHECK_CLIENT_BRAND = true;
    @Comment("If player's Minecraft client brand (e.g. fabric or forge) is set here, then this player will be kicked.")
    public List<String> BLOCKED_CLIENT_BRANDS = List.of("brand1", "brand2");
    @Comment("Time in milliseconds, how frequently will the cache list with verified players be reset. Before that time, verified players can join the server without passing antibot checks.")
    public long PURGE_CACHE_MILLIS = 3600000;
    @Comment("Max attempts, which a player has to solve the captcha.")
    public int CAPTCHA_ATTEMPTS = 2;
    @Comment("Duration of Falling Check in Minecraft ticks (1 tick = 0.05 second, 20 ticks = 1 second).")
    public int FALLING_CHECK_TICKS = 128;
    @Comment("Maximum time to check the player in milliseconds. If the player stays on the filter limbo for longer than this time, then the check will fail.")
    public int TIME_OUT = 15000;
    @Comment("Same, but for Geyser users.")
    public int GEYSER_TIME_OUT = 45000;
    @Comment("The timeout for Netty. Max ping while being on the filter limbo. Used to remove useless buffers from RAM.")
    public int MAX_PING = 3500;
    @Comment("Change the parameters below only if you know what they mean.")
    public int NON_VALID_POSITION_XZ_ATTEMPTS = 10;
    public int NON_VALID_POSITION_Y_ATTEMPTS = 10;
    public double MAX_VALID_POSITION_DIFFERENCE = 0.01;
    @Comment("Parameter for developers and contributors.")
    public boolean FALLING_CHECK_DEBUG = false;

    @Comment({
        "Available states: ONLY_POSITION, ONLY_CAPTCHA, CAPTCHA_POSITION, CAPTCHA_ON_POSITION_FAILED",
        "Meaning: ",
        "ONLY_POSITION -> Only falling check (Player will be spawned in the void, server will check player's coordinates, speed, acceleration).",
        "ONLY_CAPTCHA -> Only captcha (Map items with a captcha image will be given to the players, players need to solve captcha, and send the answer in the chat).",
        "CAPTCHA_POSITION -> Falling and Captcha checking concurrently (Player will be kicked, if he fails either falling check or captcha checking).",
        "CAPTCHA_ON_POSITION_FAILED -> Initially, the falling check will be started, but if the player fails that check, the captcha checking will be started."
    })
    public String CHECK_STATE = "CAPTCHA_POSITION";

    @Comment("See \"filter-auto-toggle.check-state-toggle\".")
    public String CHECK_STATE_NON_TOGGLED = "CAPTCHA_ON_POSITION_FAILED";

    public boolean LOAD_WORLD = false;
    @Comment("World file type: \"schematic\" (1.12.2 and lower), \"structure\" block .nbt (saved in the latest version).")
    public String WORLD_FILE_TYPE = "structure";
    public String WORLD_FILE_PATH = "world.nbt";

    @Comment("Unit of time in seconds for the Auto Toggles the Statistics.")
    public int UNIT_OF_TIME_CPS = 300;

    @Comment("Unit of time in seconds for the Auto Toggles and the Statistics.")
    public int UNIT_OF_TIME_PPS = 5;

    @Comment("A \"USERNAME:IP\" map containing information about players who should join the server without verification.")
    public Map<String, String> WHITELISTED_PLAYERS = Map.of(
        "TestBot1234", "127.0.0.1",
        "TestBot4321", "127.0.0.1"
    );

    @Create
    public FILTER_AUTO_TOGGLE FILTER_AUTO_TOGGLE;

    @Comment({
        "Minimum/maximum total connections amount per the unit of time to toggle anti-bot checks.",
        "-1 to disable the check.",
        "0 to enable on any connections per the unit of time."
    })
    public static class FILTER_AUTO_TOGGLE {

      // TODO: Норм комменты
      @Comment("All players will bypass all anti-bot checks")
      public int ALL_BYPASS = 0;

      @Comment({
          "Online mode players will bypass all anti-bot checks.",
          "Doesn't work with online-mode-verify: -1"
      })
      public int ONLINE_MODE_BYPASS = 49;

      @Comment({
          "Verify Online Mode connection before AntiBot.",
          "If connections per unit of time amount is bigger than the limit: online mode players will need to reconnect.",
          "Else: Some attacks can consume more cpu and network, and can lead to long-lasting Mojang rate-limiting."
      })
      public int ONLINE_MODE_VERIFY = 79;

      @Comment({
          "Toggles check-state/check-state-non-toggled.",
          "It is not recommended to enable it, if you want to protect your server from spam-bots.",
          "If connections per unit of time amount is bigger than the limit: check-state will be used.",
          "Else: check-state-non-toggled will be used."
      })
      public int CHECK_STATE_TOGGLE = 0;

      @Comment("The player will need to reconnect after passing AntiBot check.")
      public int NEED_TO_RECONNECT = 129;

      @Comment("Picture in the MOTD Server Ping packet will be disabled.")
      public int DISABLE_MOTD_PICTURE = 25;
    }

    @Create
    public Settings.MAIN.WORLD_COORDS WORLD_COORDS;

    public static class WORLD_COORDS {

      public int X = 0;
      public int Y = 0;
      public int Z = 0;
    }

    @Create
    public MAIN.CAPTCHA_GENERATOR CAPTCHA_GENERATOR;

    public static class CAPTCHA_GENERATOR {

      @Comment("Prepares Captcha packets, uses ~0.5GB RAM, but improves CPU performance during bot attacks. It's recommended to disable it, if you have less than 2GB of RAM.")
      public boolean PREPARE_CAPTCHA_PACKETS = false;
      @Comment("List of paths to the background image to draw on captcha. Any format, 128x128 128x128 px (will be automatically resized and stretched to the correct size). [] if empty.")
      public List<String> BACKPLATE_PATHS = List.of("");
      @Comment("Path to the font files to draw on captcha (ttf), can be empty.")
      public List<String> FONTS_PATH = List.of("");
      @Comment("Use standard fonts(SANS_SERIF/SERIF/MONOSPACED), use false only if you provide fonts path")
      public boolean USE_STANDARD_FONTS = true;
      public double LETTER_SPACING = 1.5;
      public int FONT_SIZE = 50;
      public boolean FONT_OUTLINE = false;
      public boolean FONT_ROTATE = true;
      public boolean FONT_RIPPLE = true;
      public boolean FONT_BLUR = true;
      @Comment("Set 0 to disable")
      public int CURVE_SIZE = 1;
      @Comment("Set 0 to disable")
      public int CURVES_AMOUNT = 3;
      public boolean STRIKETHROUGH = false;
      public boolean UNDERLINE = true;
      public boolean COLORIFY = false;
      public String PATTERN = "abcdefghijklmnopqrtuvwxyz1234567890";
      public int LENGTH = 3;
      public int IMAGES_COUNT = 1000;
      public List<String> RGB_COLOR_LIST = List.of("000000", "AA0000", "00AA00", "0000AA", "AAAA00", "AA00AA", "00AAAA");
    }

    @Comment(
        "Available dimensions: OVERWORLD, NETHER, THE_END"
    )
    public String BOTFILTER_DIMENSION = "THE_END";

    @Create
    public MAIN.STRINGS STRINGS;

    @Comment("Leave title fields empty to disable.")
    public static class STRINGS {

      public String RELOAD = "{PRFX} &aReloaded successfully!";
      public String RELOAD_FAILED = "{PRFX} &cReload failed, check console for details.";

      public String CLIENT_SETTINGS_KICK = "{PRFX}{NL}&cYour client doesn't send settings packets.";
      public String CLIENT_BRAND_KICK = "{PRFX}{NL}&cYour client doesn't send brand packet or it's blocked.";

      public String CHECKING_CHAT = "{PRFX} Bot-Filter check was started, please wait and don't move..";
      public String CHECKING_TITLE = "{PRFX}";
      public String CHECKING_SUBTITLE = "&aPlease wait..";

      public String CHECKING_CAPTCHA_CHAT = "{PRFX} &aPlease, solve the captcha, you have &6{0} &aattempts.";
      public String CHECKING_WRONG_CAPTCHA_CHAT = "{PRFX} &cYou entered the captcha incorrectly, you have &6{0} &cattempts left.";
      public String CHECKING_CAPTCHA_TITLE = "&aPlease solve the captcha.";
      public String CHECKING_CAPTCHA_SUBTITLE = "&aYou have &6{0} &aattempts.";

      public String SUCCESSFUL_CRACKED = "{PRFX} &aSuccessfully passed Bot-Filter check.";
      public String SUCCESSFUL_PREMIUM_KICK = "{PRFX}{NL}&aSuccessfully passed Bot-Filter check.{NL}&6Please, rejoin the server!";

      public String CAPTCHA_FAILED_KICK = "{PRFX}{NL}&cYou've mistaken in captcha check.{NL}&6Please, rejoin the server.";
      public String FALLING_CHECK_FAILED_KICK = "{PRFX}{NL}&cFalling Check was failed.{NL}&6Please, rejoin the server.";
      public String TIMES_UP = "{PRFX}{NL}&cYou have exceeded the maximum Bot-Filter check time.{NL}&6Please, rejoin the server.";

      public String STATS_FORMAT = "&c&lTotal Blocked: &6&l{0} &c&l| Connections: &6&l{1}s &c&l| Pings: &6&l{2}s &c&l| Total Connections: &6&l{3} &c&l| Ping: &6&l{4}";
      public String STATS_ENABLED = "{PRFX} &aNow you see statistics in your action bar.";
      public String STATS_DISABLED = "{PRFX} &cYou're no longer see statistics in your action bar.";

      public String SEND_PLAYER_SUCCESSFUL = "{PRFX} Successfully sent {0} to the filter limbo.";
      public String SEND_SERVER_SUCCESSFUL = "{PRFX} Successfully sent {0} players from {1} to the filter limbo.";
      public String SEND_FAILED = "{PRFX} There is no registered servers or connected players named {0}.";
    }

    @Create
    public COORDS COORDS;

    public static class COORDS {

      public double CAPTCHA_X = 0;
      @Comment("If your server supports Minecraft 1.7, don't set captcha-y to 0. https://media.discordapp.net/attachments/878241549857738793/915165038464098314/unknown.png")
      public double CAPTCHA_Y = 0;
      public double CAPTCHA_Z = 0;
      public double CAPTCHA_YAW = 90;
      public double CAPTCHA_PITCH = 38;
      public double FALLING_CHECK_YAW = 90;
      public double FALLING_CHECK_PITCH = 10;
    }
  }
}
