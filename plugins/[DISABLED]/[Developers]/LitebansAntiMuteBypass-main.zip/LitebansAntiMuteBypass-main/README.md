# LitebansAntiMuteBypass
A plugin that prevents players from bypassing a Litebans mute by preventing them from using signs, renaming items, and writing books
