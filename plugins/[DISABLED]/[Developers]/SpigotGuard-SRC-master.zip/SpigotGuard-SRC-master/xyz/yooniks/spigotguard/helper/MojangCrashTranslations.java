package xyz.yooniks.spigotguard.helper;

public final class MojangCrashTranslations
{
    public static final String[] MOJANG_CRASH_TRANSLATIONS;
    
    private MojangCrashTranslations() {
    }
    
    static {
        MOJANG_CRASH_TRANSLATIONS = new String[] { "translation.test.invalid", "translation.test.invalid2" };
    }
}
