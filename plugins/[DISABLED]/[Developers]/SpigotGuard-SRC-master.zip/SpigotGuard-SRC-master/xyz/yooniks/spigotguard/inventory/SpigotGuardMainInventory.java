package xyz.yooniks.spigotguard.inventory;

import xyz.yooniks.spigotguard.api.inventory.*;

public class SpigotGuardMainInventory extends PhasmatosClickableStableInventory
{
    public SpigotGuardMainInventory(final String s, final int n) {
        super(s, n);
    }
}
