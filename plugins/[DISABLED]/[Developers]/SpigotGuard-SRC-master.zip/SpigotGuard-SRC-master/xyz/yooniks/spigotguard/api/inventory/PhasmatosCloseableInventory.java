package xyz.yooniks.spigotguard.api.inventory;

import org.bukkit.event.inventory.*;

public interface PhasmatosCloseableInventory
{
    void onClose(final InventoryCloseEvent p0);
}
