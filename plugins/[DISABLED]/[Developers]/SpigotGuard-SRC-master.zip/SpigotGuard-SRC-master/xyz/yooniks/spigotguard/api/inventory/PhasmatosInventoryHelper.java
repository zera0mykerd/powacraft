package xyz.yooniks.spigotguard.api.inventory;

import org.bukkit.inventory.*;

public final class PhasmatosInventoryHelper
{
    public static void fillEmptiesBy(final PhasmatosInventory phasmatosInventory, final ItemStack itemStack) {
    }
    
    private PhasmatosInventoryHelper() {
    }
}
