package xyz.yooniks.spigotguard.helper;

public final class PacketDecoderHelper
{
    private PacketDecoderHelper() {
    }
}
