package org.json;

public interface JSONString
{
    String toJSONString();
}
