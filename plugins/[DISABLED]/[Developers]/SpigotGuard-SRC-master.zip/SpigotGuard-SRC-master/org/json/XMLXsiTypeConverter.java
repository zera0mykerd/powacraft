package org.json;

public interface XMLXsiTypeConverter<T>
{
    T convert(final String p0);
}
