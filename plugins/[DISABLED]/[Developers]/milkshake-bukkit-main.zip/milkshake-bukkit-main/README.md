# Milkshake Bukkit

This is just a wrapper for [MilkshakeODM](https://github.com/dotphin/milkshake-orm/)
