package dev._2lstudios.milkshakebukkit;

import org.bukkit.plugin.java.JavaPlugin;

public class MilkshakeBukkit extends JavaPlugin {
    @Override
    public void onEnable() {
        // Do nothing
    }
}