package dev.efnilite.worldserver.config;

public enum Type {

    CHAT,
    TAB,
    ECO

}
