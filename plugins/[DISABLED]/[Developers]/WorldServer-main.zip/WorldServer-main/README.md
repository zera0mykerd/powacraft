# Welcome to WorldServer
Separate chat and tab list in the worlds in your server.
Wiki is available [here!](https://efnilite.github.io/efnilite.dev/wiki/worldserver)
