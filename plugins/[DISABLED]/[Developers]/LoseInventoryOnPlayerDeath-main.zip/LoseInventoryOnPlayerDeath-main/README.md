# LoseInventoryOnPlayerDeath
 Player loses inventory when other player kills them, but does not lose inventory due to natural death.
