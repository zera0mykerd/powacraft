# Light-Cleaner
Regenerates light levels in chunks or entire worlds to clean up dark spots. Continuation of NoLagg Lighting.

Main page: https://www.spigotmc.org/resources/light-cleaner.42469/
