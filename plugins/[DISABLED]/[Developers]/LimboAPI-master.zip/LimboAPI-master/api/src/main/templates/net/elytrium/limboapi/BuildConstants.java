/*
 * Copyright (C) 2021 - 2022 Elytrium
 *
 * The LimboAPI (excluding the LimboAPI plugin) is licensed under the terms of the MIT License. For more details,
 * reference the LICENSE file in the api top-level directory.
 */

package net.elytrium.limboapi;

// The constants are replaced before compilation.
public class BuildConstants {

  public static final String LIMBO_VERSION = "${version}";
}
