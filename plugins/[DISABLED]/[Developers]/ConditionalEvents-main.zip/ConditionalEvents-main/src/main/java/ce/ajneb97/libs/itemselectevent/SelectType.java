package ce.ajneb97.libs.itemselectevent;

public enum SelectType {

	SELECT,
	DESELECT
}
