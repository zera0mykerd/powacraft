package ce.ajneb97.model.actions;

public enum ActionTargeterType {
    TO_ALL,
    TO_TARGET,
    TO_WORLD,
    TO_RANGE,
    TO_CONDITION,
    NORMAL;
}
