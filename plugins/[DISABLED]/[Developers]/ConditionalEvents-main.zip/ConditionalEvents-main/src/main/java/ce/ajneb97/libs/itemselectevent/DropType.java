package ce.ajneb97.libs.itemselectevent;

public enum DropType {

	PLAYER,
	INVENTORY
}
