# ConditionalEvents
https://www.spigotmc.org/resources/conditionalevents-custom-actions-for-certain-events-1-8-1-18.82271/
