package dev._2lstudios.prismatrade.interfaces.menus;

public class StorageMenu extends PageMenu {
    public StorageMenu(int page) {
        super(page);
    }
}
