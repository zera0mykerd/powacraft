package dev._2lstudios.prismatrade.interfaces.items;

import dev._2lstudios.interfacemaker.interfaces.InterfaceItem;

public class StorageItem extends InterfaceItem {
    
}
