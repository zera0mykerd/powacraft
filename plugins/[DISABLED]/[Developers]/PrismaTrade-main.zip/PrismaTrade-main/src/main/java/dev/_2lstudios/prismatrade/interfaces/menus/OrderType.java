package dev._2lstudios.prismatrade.interfaces.menus;

public enum OrderType {
    BUY, SELL
}
