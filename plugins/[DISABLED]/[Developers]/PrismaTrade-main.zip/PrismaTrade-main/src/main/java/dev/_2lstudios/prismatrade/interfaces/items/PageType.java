package dev._2lstudios.prismatrade.interfaces.items;

public enum PageType {
    NEXT, PREVIOUS
}
