package me.lucko.networkinterceptor.common;

public enum Platform {
    BUKKIT, // Spigot/Paper
    BUNGEE, // Bungee/Waterfall?
    VELOCITY, // Velocity
    OTHER // something else, e.g tests

}
