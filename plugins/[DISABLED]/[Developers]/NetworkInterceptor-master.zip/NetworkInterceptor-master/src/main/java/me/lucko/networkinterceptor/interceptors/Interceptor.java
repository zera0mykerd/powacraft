package me.lucko.networkinterceptor.interceptors;

public interface Interceptor {

    default void enable() {

    }

    default void disable() {

    }

}
