package me.lucko.networkinterceptor.plugin;

public enum KeepPlugins {
    ALL, ONLY_FIRST, ONLY_LAST, ONLY_EXISTANCE
}