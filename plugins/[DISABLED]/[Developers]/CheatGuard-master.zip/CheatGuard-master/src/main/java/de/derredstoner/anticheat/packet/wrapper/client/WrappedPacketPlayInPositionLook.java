package de.derredstoner.anticheat.packet.wrapper.client;

import com.comphenix.protocol.events.PacketContainer;

public class WrappedPacketPlayInPositionLook extends WrappedPacketPlayInFlying {

    public WrappedPacketPlayInPositionLook(PacketContainer packetContainer) {
        super(packetContainer);
    }
}
