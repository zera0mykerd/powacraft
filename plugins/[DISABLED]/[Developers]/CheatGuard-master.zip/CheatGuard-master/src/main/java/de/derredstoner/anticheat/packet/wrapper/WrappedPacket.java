package de.derredstoner.anticheat.packet.wrapper;

public abstract class WrappedPacket {}
