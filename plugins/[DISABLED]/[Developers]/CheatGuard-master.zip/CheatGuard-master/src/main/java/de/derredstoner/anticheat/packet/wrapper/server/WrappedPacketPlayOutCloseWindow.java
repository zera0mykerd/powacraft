package de.derredstoner.anticheat.packet.wrapper.server;

import com.comphenix.protocol.events.PacketContainer;
import de.derredstoner.anticheat.packet.wrapper.WrappedPacket;
import lombok.Getter;

@Getter
public class WrappedPacketPlayOutCloseWindow extends WrappedPacket {

    public WrappedPacketPlayOutCloseWindow(PacketContainer packetContainer) {}

}
