package de.derredstoner.anticheat.check.categories;

public enum SubCategory {
    AIM, AUTOCLICKER, HITBOX, KILLAURA, REACH, VELOCITY,
    FLY, SPEED, MOVE, JESUS,
    BADPACKET, NOFALL, TIMER,
    INVENTORY, SCAFFOLD, BARITONE
}