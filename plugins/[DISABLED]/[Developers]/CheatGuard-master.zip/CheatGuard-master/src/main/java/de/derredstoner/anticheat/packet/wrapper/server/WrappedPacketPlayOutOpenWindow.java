package de.derredstoner.anticheat.packet.wrapper.server;

import de.derredstoner.anticheat.packet.wrapper.WrappedPacket;
import com.comphenix.protocol.events.PacketContainer;
import lombok.Getter;

@Getter
public class WrappedPacketPlayOutOpenWindow extends WrappedPacket {

    public WrappedPacketPlayOutOpenWindow(PacketContainer packetContainer) {}

}
