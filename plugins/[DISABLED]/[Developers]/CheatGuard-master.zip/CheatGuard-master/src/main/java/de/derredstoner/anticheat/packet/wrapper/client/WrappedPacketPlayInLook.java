package de.derredstoner.anticheat.packet.wrapper.client;

import com.comphenix.protocol.events.PacketContainer;

public class WrappedPacketPlayInLook extends WrappedPacketPlayInFlying {

    public WrappedPacketPlayInLook(PacketContainer packetContainer) {
        super(packetContainer);
    }
}
