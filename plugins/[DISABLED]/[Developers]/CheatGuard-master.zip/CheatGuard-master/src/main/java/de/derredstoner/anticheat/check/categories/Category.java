package de.derredstoner.anticheat.check.categories;

public enum Category {
    COMBAT, MOVEMENT, PACKET, PLAYER
}