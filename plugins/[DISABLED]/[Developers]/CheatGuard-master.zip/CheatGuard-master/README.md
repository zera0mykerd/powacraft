# CheatGuard

**Free & open source AntiCheat for Minecraft, supporting server versions 1.8-1.18**

**Download:** https://www.spigotmc.org/resources/cheatguard-anticheat.75147/

**Discord: https://discord.gg/5EKqmWeURP**
