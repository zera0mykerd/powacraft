package dev._2lstudios.hamsterapi.enums;

public class HamsterHandler {
    public static final String HAMSTER_DECODER = "hapi_decoder";
    public static final String  HAMSTER_CHANNEL = "hapi_channel";
}