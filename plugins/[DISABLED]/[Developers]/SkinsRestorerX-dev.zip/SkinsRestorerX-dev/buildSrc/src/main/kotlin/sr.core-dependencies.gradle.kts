plugins {
    java
}

dependencies.compileOnly("org.projectlombok:lombok:1.18.24")
dependencies.annotationProcessor("org.projectlombok:lombok:1.18.24")
dependencies.implementation("org.jetbrains:annotations:23.0.0")
