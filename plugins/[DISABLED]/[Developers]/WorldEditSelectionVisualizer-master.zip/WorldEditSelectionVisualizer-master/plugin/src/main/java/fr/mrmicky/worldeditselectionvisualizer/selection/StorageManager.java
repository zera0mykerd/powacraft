package fr.mrmicky.worldeditselectionvisualizer.selection;

import fr.mrmicky.worldeditselectionvisualizer.WorldEditSelectionVisualizer;
import fr.mrmicky.worldeditselectionvisualizer.event.VisualizationToggleEvent;
import org.bukkit.Bukkit;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

import java.io.File;
import java.io.IOException;
import java.util.logging.Level;

public class StorageManager {

    private final WorldEditSelectionVisualizer plugin;

    private final File playersFile;
    private final FileConfiguration playersConfig;
    private final ConfigurationSection playersSection;

    public StorageManager(WorldEditSelectionVisualizer plugin) {
        this.plugin = plugin;

        playersFile = new File(plugin.getDataFolder(), "players.yml");

        playersConfig = YamlConfiguration.loadConfiguration(playersFile);

        ConfigurationSection section = playersConfig.getConfigurationSection("players");

        playersSection = section != null ? section : playersConfig.createSection("players");
    }

    public boolean isEnabled(Player player, SelectionType type) {
        String key = player.getUniqueId() + "." + type.getName();

        return playersSection.getBoolean(key, type.isEnabledByDefault());
    }

    public void setEnable(Player player, SelectionType type, boolean enable) {
        playersSection.set(player.getUniqueId() + "." + type.getName(), enable);

        Bukkit.getPluginManager().callEvent(new VisualizationToggleEvent(player, enable));

        save();
    }

    private void save() {
        try {
            playersConfig.save(playersFile);
        } catch (IOException e) {
            plugin.getLogger().log(Level.SEVERE, "Error while saving players.yml", e);
        }
    }
}
