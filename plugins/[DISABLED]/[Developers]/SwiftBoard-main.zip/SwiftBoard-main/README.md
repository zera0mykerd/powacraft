# SwiftBoard

Asynchronous Scoreboard API using packets.
