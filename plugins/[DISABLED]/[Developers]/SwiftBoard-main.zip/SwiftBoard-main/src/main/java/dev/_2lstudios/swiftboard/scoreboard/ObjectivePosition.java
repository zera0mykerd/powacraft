package dev._2lstudios.swiftboard.scoreboard;

public enum ObjectivePosition {
    
}
