package svar.ajneb97.model.structure;

public enum VariableType {
    GLOBAL,
    PLAYER
}
