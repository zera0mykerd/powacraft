# ServerVariables
https://www.spigotmc.org/resources/servervariables-custom-data-and-variables-for-players-1-8-1-19.107803/
