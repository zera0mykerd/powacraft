# Improvements
* Fixed context and spelling in config error messages.
* Removed the long term fine
