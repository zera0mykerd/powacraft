# Configuration
* Changed the default configuration and also added positive leverage on newbies.
