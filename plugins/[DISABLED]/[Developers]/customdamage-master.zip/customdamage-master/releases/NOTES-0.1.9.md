# Bugfixes
* Don't duplicate messages to console.
* Fixed JS engine, added dependency to https://www.spigotmc.org/resources/nashornjs-provider-and-cli.91204/
