package com.gmail.uprial.customdamage.config;

public class InvalidConfigException extends Exception {
    public InvalidConfigException(String message) {
        super(message);
    }
}