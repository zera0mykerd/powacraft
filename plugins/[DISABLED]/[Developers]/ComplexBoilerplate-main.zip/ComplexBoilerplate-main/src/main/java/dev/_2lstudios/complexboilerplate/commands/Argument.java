package dev._2lstudios.complexboilerplate.commands;

public enum Argument {
  STRING, LARGE_STRING, INT, BOOL, PLAYER, OFFLINE_PLAYER, WORLD, MATERIAL, SOUND
}