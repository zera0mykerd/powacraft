# HostflowMalwareRemover
A command line tool to detect &amp; remove "hostflow" malware from infected minecraft plugins.

## Installation
Download it and drop it on your server root folder (where files like bukkit.yml etc are located)

## Usage

#### Detection mode:
```
Start your server with HostflowMalwareRemover.jar

- java -jar HostflowMalwareRemover.jar

If you use some panel you will have to select custom server version and then select this jar.
```

If it says it found plugins with malware then you should do the the next step.

#### Remover mode:

```
Start your server with HostflowMalwareRemover.jar and add -D"remover=true"

- java -D"remover=true" -jar HostflowMalwareRemover.jar

If you use some panel you will have to select custom server version and then select this jar,
now in your panel in parameters add at start -D"remover=true"
(if you cant do that you will have to contact your host provider and ask them to add that or run this tool for you)
(or you can also download all the plugins from your host and run the tool on your PC)
```

When it is done all the clean plugins will be in "plugins-clean" folder,
then rename "plugins" folder to "plugins1" or something (for backup purposes incase it doesnt remove the malware properly)
and now you can rename "plugins-clean" to "plugins"

NOTE: It might break some plugins that use the actual [Javassist](https://github.com/jboss-javassist/javassist) library,
if it does you should download again that plugin from official sources.

#### Libraries used:
- [ASM &amp; ASM Tree](https://asm.ow2.io/)

### You can message me on discord if you have issues or just would like to chat - Haizivs#7206