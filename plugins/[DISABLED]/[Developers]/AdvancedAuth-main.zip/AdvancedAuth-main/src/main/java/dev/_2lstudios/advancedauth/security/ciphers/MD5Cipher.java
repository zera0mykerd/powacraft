package dev._2lstudios.advancedauth.security.ciphers;

import dev._2lstudios.advancedauth.security.CommonCipher;

public class MD5Cipher extends CommonCipher {
    public MD5Cipher() {
        super("MD5");
    }
}
