package dev._2lstudios.advancedauth.players;

public enum AuthState {
    LOGGED,
    UNLOGGED,
    GUEST,
    UNFETCHED
}
