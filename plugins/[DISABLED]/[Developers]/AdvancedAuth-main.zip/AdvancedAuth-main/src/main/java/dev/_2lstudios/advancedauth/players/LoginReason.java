package dev._2lstudios.advancedauth.players;

public enum LoginReason {
    PASSWORD, SESSION_RESUME, FORCED, REGISTERED
}
