# Bukkit Boilerplate

Sample project to create Plugins for Bukkit.
