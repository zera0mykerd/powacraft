# Bukkit Boilerplate

Boilerplate/Template for a Bukkit Plugin

### Section 1 ✔️

- [x] First task
- [x] Second task  
- [x] Third task  

### Section 2

- [x] Fourth task
- [ ] Fifth task  
- [ ] Sixth task  

### Section 3

- [ ] Seventh task
- [ ] Eighth task  
- [ ] Nineth task  
