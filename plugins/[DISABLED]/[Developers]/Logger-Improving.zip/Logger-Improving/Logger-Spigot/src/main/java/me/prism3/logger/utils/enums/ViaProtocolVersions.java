package me.prism3.logger.utils.enums;

public enum ViaProtocolVersions {

    v1_8,

}
