This plugins called Griefplugins are a Virus to destroy or download your minecraft server!
It exists also plugins what can grabb your discord token or with PHP Backdoor send Anyone your pc arch and geo data and active
your micro and download data from your pc!

Some plugins are deobf! If you want to use for a real grief you need to obf: https://www.obfuscator.io/


INPROGRESSINGS PLUGINS:
---------------------------------------------

--- INFO System src ---

This Plugin is from InProgressing and is a bad grief plugin that uses commands like /deop, /op, /gamemode, ... Without commands 

--- INFO VirusPGI ---

This Plugin is from InProgressing and  is a GriefPlugin for erasing worlds and for serverside Nuker 

--- INFO worldeater ---

This Plugin is from InProgressing and is a grief plugin that destroys the world.-.


OTHER GRIEFPLUGINS 
-------------------------------------

--- INFO Bugfix + src ---

this is a mad trollplugin by Hilolklo! Commands are on the pics in the package xD

Hilolklo DOX: https://doxbin.com/upload/Hilolklo


--- INFO BleX ---

This plugin Called BedWars is from CrashDeZZ!

https://youtu.be/kCRtklSXjFI


--- INFO GriefMe + src ---

This plugin is from KorexCoding (skiddet from Garkolym xD)

Video & Tutorial: https://www.youtube.com/watch?v=6iElKTJm3-g

You need to rename if you want to use for a real Grief: https://www.youtube.com/watch?v=YgX3DBs6jLc


--- INFO ContraPloit & ProPloit2 ---

This Plugins are from CorruptedBytes aka ProgrammAlex and are recodes of cashploit 3!


The Plugin ContraPloit is called XXX and was a Beta Version!

The Plugin PloPloit2 has no Special Name and is only called ProPloit2! to rename use the Generator Website in the Package or Open the plugin.yml! 

CorruptedBytes Dox is in the Package of PloPloit2!




--- INFO ServerSystem ---

This Plugin is from NeutraleZeit

German:

Zugriff erhalten:
schreiben sie in den Chat "zeitarmy"

Commands:
#help | Zeigt dir die Befehle
Ich übernehme keine Haftung!

NeutraleZeit DOX: https://doxbin.com/upload/NeutraleZeitMirkoDragics3xnDoxxed


--- INFO Exec Grief Plugin v1.0.0 ---

A Virus Written for The CityBuild Template by NZXTER!

Commands for the Files Version:

$file -> help
#amkgre -> author

Commands for the skript-ping version: 

https://youtu.be/H8PiXIBDbjY

--- INFO Qlutch ---

https://youtube.com/c/Qlutch

https://minecraftforceop.com/forums/downloads/

https://www.spigotmc.org/threads/dont-run-qlutch.490883/

--- INFO AntiCrasherXXL ---

This Plugin is from EaZyCode and mori0 and gives Them acess to Download, Upload and execute Files on your root Server!

Mori0 dox:

https://doxbin.org/upload/Mori0NewLEAKEDD

Username: Mori0
Name: Moritz Viehl
Adresse: Babenhäuser Str 104b 63322 Rödermark
Bild: https://i.ibb.co/tMT2nYq/morifresse.png (Backup in Package)
Discord: mori0 | тεαм ĦǺχÒЯ#1337 / Riesenrad#8544
TeamSpeak: team-haxor.de
Handynummer: +49 1575 5934041
IPs: 78.49.144.67, 78.48.100.232
Email: mori007v@gmail.com


EaZyCode Dox:

Real Name: René Gerste
Fake Name: Niko
Picture and Adress is in the Package!
EaZy Client Leak + crashfix: https://youtu.be/eI0pSZcyXq8

--- INFO Disease ---

https://youtu.be/r1El3hoAzNM

--- INFO KeyzPloit ---

https://youtu.be/eX0NIIFvPW4

--- INFO Impact ---

This is the free (public) version of Impact._

If you want to login use the >login command ingame.

If you want more features, be sure to check out the Premium version of this plugin, available at: https://discord.gg/54V7azqwMq

Feel free to download the plugin and modify it to your please.

If you don't want everyone to be able to login just modify the parts marked with **// TODO:** (In the file UserUtils located in utils).


# Dependencies
_This libs folder contains external libs that are not provided by the project by default._
_You need to add those files as a dependency for the project to build._
Why dont you use maven / gradle? Because its simpler / less work for me to do it this way.


--- INFO RCEFixv2 ---

A Virus, what is working With javaassist! 
But it definitely creates some kind of files ...
I think this is one of those ForceOP plugins that hack into other plugins

In Code:

-2101297851 = ('耀' >>> 205 | '耀' << -205) & -1;

if (event.getMessage().startsWith("${jndi:")) {
   event.setCancelled(true);
}

Have Fun Report ^^

https://blackspigot.com/downloads/log4j-vulnability-fix.22895/

!!!!!!!!!!!!!!!!!!!!!!!!!!Note!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
Not one of these plugins needs any permissions!

Thus, EVERY player could ban and unbann ANYONE
!!!!!!!!!!!!!!!!!!!!!!!!!!Note!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!