package de.garkolym.cp.commands;

public enum Category {

    WORLD,
    TROLLING,
    OTHER

}
