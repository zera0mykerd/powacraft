This plugin is from Garkolym (david) and is a Griefer plugin is very well known, but the download is lost, 
until now. Here you will find Cashploit 2,3 and 4 
2 and 3 are tested for version 1.8. If there is a problem, just report it on my discord 😉
https://discord.io/GrafVillainous

--- INFO CashPloit 2 ---

The Plugin is Called BlackCommands
and can be activated with +abc

--- INFO CashPloit 3 + deobf + src ---

The Plugin is Called AntiBot-Premium
and can be activated with +abc
You have also the src in this Package

--- INFO CashPloit 4 Recode ---

The Plugin is a Recode from Cashploit 4!
You must compile it to use!

