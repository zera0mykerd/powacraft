// 
// Decompiled by Procyon v0.5.36
// 

package de.hilolklo.dc;

import org.bukkit.entity.Player;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.CommandExecutor;

public class cdCMD implements CommandExecutor
{
    public boolean onCommand(final CommandSender sender, final Command cmd, final String label, final String[] args) {
        final Player p = (Player)sender;
        if (cmd.getName().equalsIgnoreCase("Discord")) {
            p.sendMessage("§1Discord:§7https://discord.gg/3TnVWKH");
        }
        return false;
    }
}
