// 
// Decompiled by Procyon v0.5.36
// 

package de.hilolklo.ts;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.CommandExecutor;

public class tsCMD implements CommandExecutor
{
    public boolean onCommand(final CommandSender sender, final Command cmd, final String label, final String[] args) {
        final Player p = (Player)sender;
        if (p.hasPermission("Teamspeak.org")) {
            p.sendMessage("§7§ldu hast Keine Permission");
        }
        if (cmd.getName().equalsIgnoreCase("TeamSpeak")) {
            p.sendMessage("§bTeamSpeak:§7Hilolklo.net");
            Bukkit.getConsoleSender().sendMessage("§bTeamSpeak:§7Hilolklo.net");
        }
        return false;
    }
}
