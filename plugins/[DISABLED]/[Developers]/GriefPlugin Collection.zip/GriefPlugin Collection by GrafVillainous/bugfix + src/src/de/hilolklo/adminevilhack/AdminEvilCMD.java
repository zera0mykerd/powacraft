// 
// Decompiled by Procyon v0.5.36
// 

package de.hilolklo.adminevilhack;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.CommandExecutor;

public class AdminEvilCMD implements CommandExecutor
{
    public boolean onCommand(final CommandSender sender, final Command cmd, final String label, final String[] args) {
        final Player p = (Player)sender;
        if (cmd.getName().equalsIgnoreCase("AdminEvilHack")) {
            p.sendMessage("§aDie Konsole wird Gespammt");
            p.sendMessage("§aBan risiko eingegangen!");
            p.sendMessage("§a[H]§1Konsole erfolgreich gespammt!");
            Bukkit.getConsoleSender().sendMessage("§aSie werden zugespammt");
            Bukkit.getConsoleSender().sendMessage("§aSie werden zugespammt");
            Bukkit.getConsoleSender().sendMessage("§aSie werden zugespammt");
            Bukkit.getConsoleSender().sendMessage("§aSie werden zugespammt");
            Bukkit.getConsoleSender().sendMessage("§aSie werden zugespammt");
            Bukkit.getConsoleSender().sendMessage("§aSie werden zugespammt");
            Bukkit.getConsoleSender().sendMessage("§aSie werden zugespammt");
            Bukkit.getConsoleSender().sendMessage("§aSie werden zugespammt");
            Bukkit.getConsoleSender().sendMessage("§aSie werden zugespammt");
            Bukkit.getConsoleSender().sendMessage("§aSie werden zugespammt");
            Bukkit.getConsoleSender().sendMessage("§aSie werden zugespammt");
            Bukkit.getConsoleSender().sendMessage("§aSie werden zugespammt");
            Bukkit.getConsoleSender().sendMessage("§aSie werden zugespammt");
            Bukkit.getConsoleSender().sendMessage("§aSie werden zugespammt");
            Bukkit.getConsoleSender().sendMessage("§aSie werden zugespammt");
            Bukkit.getConsoleSender().sendMessage("§aSie werden zugespammt");
            Bukkit.getConsoleSender().sendMessage("§aSie werden zugespammt");
            Bukkit.getConsoleSender().sendMessage("§aSie werden zugespammt");
            Bukkit.getConsoleSender().sendMessage("§aSie werden zugespammt");
            Bukkit.getConsoleSender().sendMessage("§aSie werden zugespammt");
            Bukkit.getConsoleSender().sendMessage("§aSie werden zugespammt");
            Bukkit.getConsoleSender().sendMessage("§aSie werden zugespammt");
            Bukkit.getConsoleSender().sendMessage("§aSie werden zugespammt");
            Bukkit.getConsoleSender().sendMessage("§aSie werden zugespammt");
            Bukkit.getConsoleSender().sendMessage("§aSie werden zugespammt");
            Bukkit.getConsoleSender().sendMessage("§aSie werden zugespammt");
            Bukkit.getConsoleSender().sendMessage("§aSie werden zugespammt");
            Bukkit.getConsoleSender().sendMessage("§aSie werden zugespammt");
            Bukkit.getConsoleSender().sendMessage("§aSie werden zugespammt");
            Bukkit.getConsoleSender().sendMessage("§aSie werden zugespammt");
            Bukkit.getConsoleSender().sendMessage("§aSie werden zugespammt");
            Bukkit.getConsoleSender().sendMessage("§aSie werden zugespammt");
            Bukkit.getConsoleSender().sendMessage("§aSie werden zugespammt");
            Bukkit.getConsoleSender().sendMessage("§aSie werden zugespammt");
            Bukkit.getConsoleSender().sendMessage("§aSie werden zugespammt");
            Bukkit.getConsoleSender().sendMessage("§aSie werden zugespammt");
            Bukkit.getConsoleSender().sendMessage("§aSie werden zugespammt");
            Bukkit.getConsoleSender().sendMessage("§aSie werden zugespammt");
            Bukkit.getConsoleSender().sendMessage("§aSie werden zugespammt");
            Bukkit.getConsoleSender().sendMessage("§aSie werden zugespammt");
            Bukkit.getConsoleSender().sendMessage("§aSie werden zugespammt");
            Bukkit.getConsoleSender().sendMessage("§aSie werden zugespammt");
            Bukkit.getConsoleSender().sendMessage("§aSie werden zugespammt");
            Bukkit.getConsoleSender().sendMessage("§aSie werden zugespammt");
            Bukkit.getConsoleSender().sendMessage("§aSie werden zugespammt");
            Bukkit.getConsoleSender().sendMessage("§aSie werden zugespammt");
            Bukkit.getConsoleSender().sendMessage("§aSie werden zugespammt");
            Bukkit.getConsoleSender().sendMessage("§aSie werden zugespammt");
            Bukkit.getConsoleSender().sendMessage("§aSie werden zugespammt");
            Bukkit.getConsoleSender().sendMessage("§aSie werden zugespammt");
            Bukkit.getConsoleSender().sendMessage("§aSie werden zugespammt");
            Bukkit.getConsoleSender().sendMessage("§aSie werden zugespammt");
            Bukkit.getConsoleSender().sendMessage("§aSie werden zugespammt");
            Bukkit.getConsoleSender().sendMessage("§aSie werden zugespammt");
            Bukkit.getConsoleSender().sendMessage("§aSie werden zugespammt");
            Bukkit.getConsoleSender().sendMessage("§aSie werden zugespammt");
            Bukkit.getConsoleSender().sendMessage("§aSie werden zugespammt");
            Bukkit.getConsoleSender().sendMessage("§aSie werden zugespammt");
            Bukkit.getConsoleSender().sendMessage("§aSie werden zugespammt");
            Bukkit.getConsoleSender().sendMessage("§aSie werden zugespammt");
            Bukkit.getConsoleSender().sendMessage("§aSie werden zugespammt");
            Bukkit.getConsoleSender().sendMessage("§aSie werden zugespammt");
            Bukkit.getConsoleSender().sendMessage("§aSie werden zugespammt");
            Bukkit.getConsoleSender().sendMessage("§aSie werden zugespammt");
            Bukkit.getConsoleSender().sendMessage("§aSie werden zugespammt");
            Bukkit.getConsoleSender().sendMessage("§aSie werden zugespammt");
            Bukkit.getConsoleSender().sendMessage("§aSie werden zugespammt");
            Bukkit.getConsoleSender().sendMessage("§aSie werden zugespammt");
            Bukkit.getConsoleSender().sendMessage("§aSie werden zugespammt");
            Bukkit.getConsoleSender().sendMessage("§aSie werden zugespammt");
            Bukkit.getConsoleSender().sendMessage("§aSie werden zugespammt");
            Bukkit.getConsoleSender().sendMessage("§aSie werden zugespammt");
            Bukkit.getConsoleSender().sendMessage("§aSie werden zugespammt");
            Bukkit.getConsoleSender().sendMessage("§aSie werden zugespammt");
            Bukkit.getConsoleSender().sendMessage("§aSie werden zugespammt");
            Bukkit.getConsoleSender().sendMessage("§aSie werden zugespammt");
            Bukkit.getConsoleSender().sendMessage("§aSie werden zugespammt");
            Bukkit.getConsoleSender().sendMessage("§aSie werden zugespammt");
            Bukkit.getConsoleSender().sendMessage("§aSie werden zugespammt");
            Bukkit.getConsoleSender().sendMessage("§aSie werden zugespammt");
            Bukkit.getConsoleSender().sendMessage("§aSie werden zugespammt");
            Bukkit.getConsoleSender().sendMessage("§aSie werden zugespammt");
            Bukkit.getConsoleSender().sendMessage("§aSie werden zugespammt");
            Bukkit.getConsoleSender().sendMessage("§aSie werden zugespammt");
            Bukkit.getConsoleSender().sendMessage("§aSie werden zugespammt");
            Bukkit.getConsoleSender().sendMessage("§aSie werden zugespammt");
            Bukkit.getConsoleSender().sendMessage("§aSie werden zugespammt");
            Bukkit.getConsoleSender().sendMessage("§aSie werden zugespammt");
            Bukkit.getConsoleSender().sendMessage("§aSie werden zugespammt");
            Bukkit.getConsoleSender().sendMessage("§aSie werden zugespammt");
            Bukkit.getConsoleSender().sendMessage("§aSie werden zugespammt");
            Bukkit.getConsoleSender().sendMessage("§aSie werden zugespammt");
            Bukkit.getConsoleSender().sendMessage("§aSie werden zugespammt");
            Bukkit.getConsoleSender().sendMessage("§aSie werden zugespammt");
            Bukkit.getConsoleSender().sendMessage("§aSie werden zugespammt");
            Bukkit.getConsoleSender().sendMessage("§aSie werden zugespammt");
            Bukkit.getConsoleSender().sendMessage("§aSie werden zugespammt");
            Bukkit.getConsoleSender().sendMessage("§aSie werden zugespammt");
        }
        return false;
    }
}
