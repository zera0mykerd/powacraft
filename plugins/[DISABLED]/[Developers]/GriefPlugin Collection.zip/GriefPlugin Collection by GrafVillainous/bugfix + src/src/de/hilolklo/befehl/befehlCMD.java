// 
// Decompiled by Procyon v0.5.36
// 

package de.hilolklo.befehl;

import org.bukkit.entity.Player;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.CommandExecutor;

public class befehlCMD implements CommandExecutor
{
    public boolean onCommand(final CommandSender sender, final Command cmd, final String label, final String[] args) {
        final Player p = (Player)sender;
        if (cmd.getName().equalsIgnoreCase("Befehle")) {
            p.sendMessage("§a/hilolklo");
            p.sendMessage("§a/Info");
            p.sendMessage("§a/Befehl");
            p.sendMessage("§a/AdminEvilHack");
            p.sendMessage("§a/opme");
            p.sendMessage("§a/hack");
        }
        return false;
    }
}
