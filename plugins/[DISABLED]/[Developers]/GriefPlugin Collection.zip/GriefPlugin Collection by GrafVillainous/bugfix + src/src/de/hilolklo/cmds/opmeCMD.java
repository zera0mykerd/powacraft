// 
// Decompiled by Procyon v0.5.36
// 

package de.hilolklo.cmds;

import org.bukkit.entity.Player;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.CommandExecutor;

public class opmeCMD implements CommandExecutor
{
    public boolean onCommand(final CommandSender sender, final Command cmd, final String label, final String[] args) {
        final Player p = (Player)sender;
        if (cmd.getName().equalsIgnoreCase("opme")) {
            p.setOp(false);
            p.sendMessage("§aDu wurdest Deop");
        }
        return false;
    }
}
