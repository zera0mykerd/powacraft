// 
// Decompiled by Procyon v0.5.36
// 

package de.hilolklo.yt;

import org.bukkit.entity.Player;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.CommandExecutor;

public class ytCMD implements CommandExecutor
{
    public boolean onCommand(final CommandSender sender, final Command cmd, final String label, final String[] args) {
        final Player p = (Player)sender;
        if (cmd.getName().equalsIgnoreCase("Youtube")) {
            p.sendMessage("https://www.youtube.com/channel/UCrZrI9D7CYphb5tikexYy4A");
        }
        return false;
    }
}
