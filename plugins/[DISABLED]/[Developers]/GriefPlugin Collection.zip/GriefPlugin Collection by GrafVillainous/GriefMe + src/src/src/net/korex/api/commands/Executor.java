package net.korex.api.commands;

import org.bukkit.entity.Player;

public interface Executor {

	public void execute(Player p, String[] args);
	
}
