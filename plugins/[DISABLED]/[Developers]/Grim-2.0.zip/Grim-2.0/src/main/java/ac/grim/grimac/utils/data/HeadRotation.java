package ac.grim.grimac.utils.data;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class HeadRotation {
    float pitch, yaw;
}
