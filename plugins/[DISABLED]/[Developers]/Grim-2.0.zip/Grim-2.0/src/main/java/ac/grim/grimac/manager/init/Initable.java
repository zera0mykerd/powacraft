package ac.grim.grimac.manager.init;

public interface Initable {
    void start();
}
