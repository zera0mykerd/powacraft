package ac.grim.grimac.manager.tick;

public interface Tickable {
    void tick();
}
