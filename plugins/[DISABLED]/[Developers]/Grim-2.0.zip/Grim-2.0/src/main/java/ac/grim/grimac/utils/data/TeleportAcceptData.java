package ac.grim.grimac.utils.data;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TeleportAcceptData {
    boolean isTeleport;
    SetBackData setback;
    TeleportData teleportData;
}
