package ac.grim.grimac.utils.inventory;

public enum ClickAction {
    PRIMARY,
    SECONDARY
}
