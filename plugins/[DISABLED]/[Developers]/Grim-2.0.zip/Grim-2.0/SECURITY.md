# Security Policy

## Supported Versions

Vulnerability must be reproducable on the latest grim version on spigotmc or newer.

## Reporting a Vulnerability

If there's a major bypass that would affect gameplay if reported publicly then join Grim's discord [here](https://discord.com/invite/FNRrcGAybJ) and message DefineOutside.
