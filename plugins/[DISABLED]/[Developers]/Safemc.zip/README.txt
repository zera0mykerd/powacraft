plugin cracked by memexurer and Noxerek

Plugin doesn't work on localhost