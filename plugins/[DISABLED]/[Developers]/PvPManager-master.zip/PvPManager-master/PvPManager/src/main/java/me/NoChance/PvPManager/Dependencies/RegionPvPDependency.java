package me.NoChance.PvPManager.Dependencies;

public interface RegionPvPDependency extends RegionDependency, PvPDependency {

}
