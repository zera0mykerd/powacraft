package me.NoChance.PvPManager.Settings;

public class UserDataFields {

	public static final String PVP_STATUS = "pvpstatus";
	public static final String TOGGLE_TIME = "toggletime";
	public static final String NEWBIE = "newbie";
	public static final String NEWBIE_TIMELEFT = "newbie_timeleft";

	private UserDataFields() {}
}
