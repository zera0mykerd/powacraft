package nitrous.mbc;

import nitrous.cpu.Emulator;

/**
 * Implementation of Memory Bank Chip 2.
 *
 * @author Tudor
 */
public class MBC2 extends Memory
{
    /**
     * {@inheritDoc}
     */
    public MBC2(Emulator core)
    {
        super(core);
        throw new UnsupportedOperationException();
    }
}
