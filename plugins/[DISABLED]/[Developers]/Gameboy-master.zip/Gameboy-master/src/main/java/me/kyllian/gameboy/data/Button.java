package me.kyllian.gameboy.data;

public enum Button {

    BUTTONLEFT, BUTTONRIGHT, BUTTONUP, BUTTONDOWN, BUTTONA, BUTTONB, BUTTONSTART, BUTTONSELECT

}
