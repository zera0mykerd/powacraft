package dev._2lstudios.advancedparties.requests;

public enum RequestStatus {
    NONE, PENDING, DENIED
}
