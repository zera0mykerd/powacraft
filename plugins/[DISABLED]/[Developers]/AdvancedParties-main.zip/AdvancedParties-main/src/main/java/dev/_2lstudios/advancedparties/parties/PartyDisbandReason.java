package dev._2lstudios.advancedparties.parties;

public enum PartyDisbandReason {
    BY_LEADER, TIMEOUT, OTHER
}
