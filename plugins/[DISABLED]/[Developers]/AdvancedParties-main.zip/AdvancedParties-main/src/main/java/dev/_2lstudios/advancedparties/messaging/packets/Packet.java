package dev._2lstudios.advancedparties.messaging.packets;

public interface Packet {
  public String getChannel();
}
