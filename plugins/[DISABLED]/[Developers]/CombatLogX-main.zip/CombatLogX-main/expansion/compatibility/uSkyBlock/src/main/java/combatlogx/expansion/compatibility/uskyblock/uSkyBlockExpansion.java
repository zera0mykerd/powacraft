package combatlogx.expansion.compatibility.uskyblock;

import com.github.sirblobman.combatlogx.api.ICombatLogX;
import com.github.sirblobman.combatlogx.api.expansion.Expansion;

import combatlogx.expansion.compatibility.uskyblock.listener.ListeneruSkyBlock;

public final class uSkyBlockExpansion extends Expansion {
    public uSkyBlockExpansion(ICombatLogX plugin) {
        super(plugin);
    }

    @Override
    public void onLoad() {
        // Do Nothing
    }

    @Override
    public void onEnable() {
        if (!checkDependency("uSkyBlock", true)) {
            selfDisable();
            return;
        }

        new ListeneruSkyBlock(this).register();
    }

    @Override
    public void onDisable() {
        // Do Nothing
    }

    @Override
    public void reloadConfig() {
        // Do Nothing
    }
}
