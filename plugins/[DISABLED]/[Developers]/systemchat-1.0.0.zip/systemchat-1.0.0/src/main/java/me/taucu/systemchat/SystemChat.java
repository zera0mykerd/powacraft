package me.taucu.systemchat;

import me.taucu.systemchat.listeners.PlayerEvents;
import me.taucu.systemchat.net.OutboundHandler;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

public class SystemChat extends JavaPlugin {

    public static SystemChat instance;

    public static SystemChat getInstance() {
        return instance;
    }

    @Override
    public void onEnable() {
        instance = this;
        Bukkit.getPluginManager().registerEvents(new PlayerEvents(), this);
        for (Player p : Bukkit.getOnlinePlayers()) {
            OutboundHandler.attach(p);
        }
    }

    @Override
    public void onDisable() {
        for (Player p : Bukkit.getOnlinePlayers()) {
            OutboundHandler.detach(p);
        }
    }
}
