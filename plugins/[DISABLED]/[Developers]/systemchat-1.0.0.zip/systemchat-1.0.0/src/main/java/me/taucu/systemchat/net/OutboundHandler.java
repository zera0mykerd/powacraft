package me.taucu.systemchat.net;

import io.netty.channel.*;
import me.taucu.systemchat.SystemChat;
import net.minecraft.core.RegistryAccess;
import net.minecraft.network.chat.ChatType;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundPlayerChatPacket;
import net.minecraft.network.protocol.game.ClientboundSystemChatPacket;
import net.minecraft.server.MinecraftServer;
import org.bukkit.craftbukkit.v1_19_R1.entity.CraftPlayer;
import org.bukkit.entity.Player;

import java.util.NoSuchElementException;
import java.util.Optional;

public class OutboundHandler extends ChannelOutboundHandlerAdapter {

    public static final String NAME = "me.taucu.systemchat:outbound_handler";

    public final RegistryAccess registryAccess = MinecraftServer.getServer().registryAccess();

    public final Player player;

    private OutboundHandler(Player player) {
        this.player = player;
    }

    public static synchronized void attach(Player player) {
        ChannelPipeline pipe = getPipeline(player);
        ChannelHandler handler = pipe.get(NAME);
        if (handler != null) {
            detach(player);
        }
        pipe.addBefore("packet_handler", NAME, new OutboundHandler(player));
    }

    public static synchronized void detach(Player player) {
        try {
            getPipeline(player).remove(NAME);
        } catch (NoSuchElementException ignored) {}
    }

    public static ChannelPipeline getPipeline(Player player) {
        CraftPlayer p = (CraftPlayer) player;
        return p.getHandle().connection.connection.channel.pipeline();
    }

    @Override
    public void write(ChannelHandlerContext ctx, Object msg, ChannelPromise promise) throws Exception {
        if (msg instanceof ClientboundPlayerChatPacket chat) {
            Component comp = chat.message().unsignedContent().orElse(chat.message().signedContent().decorated());

            Optional<ChatType.Bound> bound = chat.resolveChatType(registryAccess);
            if (bound.isPresent()) {
                comp = bound.get().decorate(comp);
            } else {
                SystemChat.getInstance().getLogger().warning("Could not resolve chat bound for player=" + player.getName() + ", packet=" + chat);
            }

            msg = new ClientboundSystemChatPacket(comp, false);
        }

        super.write(ctx, msg, promise);
    }

}
