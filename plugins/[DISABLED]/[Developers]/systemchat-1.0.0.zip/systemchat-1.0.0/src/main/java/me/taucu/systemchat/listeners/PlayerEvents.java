package me.taucu.systemchat.listeners;

import me.taucu.systemchat.net.OutboundHandler;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;

public class PlayerEvents implements Listener {

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        OutboundHandler.attach(e.getPlayer());
    }

}
