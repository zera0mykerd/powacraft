rootProject.name = "SystemChat"

pluginManagement {
    repositories {
        gradlePluginPortal()
        maven {
            url = uri("https://papermc.io/repo/repository/maven-public/")
        }
    }
}
