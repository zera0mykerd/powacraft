SpigotMC Build Data
===================

Data needed to build custom MC servers.
