# Kickless Variation
Replaces all kick commands with a simple notification.

Helpful for debugging or modifying checks without getting kicked.