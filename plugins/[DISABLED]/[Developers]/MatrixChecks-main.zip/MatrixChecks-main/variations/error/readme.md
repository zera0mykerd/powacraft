# Fake Error Variation
All kick messages are replaced with existing and made-up error messages.

This confuses hackers since kick messages are replaced with generic errors!

Admins will still be able to read the kicks in both of Matrix's logs.