# Ghost Variant
Unfinished