# Combos
This directory contains additional variations that are built on top of other variations.

For example, "lenient-error" takes the "lenient" variation, then applies the "error" variation.