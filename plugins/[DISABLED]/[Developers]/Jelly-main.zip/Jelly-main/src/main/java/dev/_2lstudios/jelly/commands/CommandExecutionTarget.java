package dev._2lstudios.jelly.commands;

public enum CommandExecutionTarget {
    ONLY_PLAYER, ONLY_CONSOLE, BOTH
}
