package dev._2lstudios.jelly.gui;

public enum InventoryType {
    CHEST
}
