package dev._2lstudios.spawnplus.config;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.Plugin;

public class ConfigManager {
    private Map<String, YamlConfiguration> configs;
    private Plugin plugin;

    public ConfigManager(Plugin plugin) {
        this.configs = new HashMap<>();
        this.plugin = plugin;
    }

    public YamlConfiguration getConfig(File file) {
        YamlConfiguration config;

        try {
            config = YamlConfiguration.loadConfiguration(file);
        } catch (IllegalArgumentException ex) {
            config = new YamlConfiguration();
        }

        return config;
    }

    public YamlConfiguration getConfig(String name) {
        if (configs.containsKey(name)) {
            return configs.get(name);
        }

        File file = new File(plugin.getDataFolder(), name);
        YamlConfiguration config = getConfig(file);

        configs.put(name, config);

        return config;
    }

    public YamlConfiguration saveConfig(String name) {
        File configFile = new File(plugin.getDataFolder(), name);

        if (!configFile.exists()) {
            configFile.getParentFile().mkdirs();
            plugin.saveResource(name, false);
        }

        return getConfig(name);
    }

    public void save(YamlConfiguration config, String name) {
        File configFile = new File(plugin.getDataFolder(), name);

        try {
            config.save(configFile);
        } catch (IOException e) {
            // Ignored
        }
    }
}