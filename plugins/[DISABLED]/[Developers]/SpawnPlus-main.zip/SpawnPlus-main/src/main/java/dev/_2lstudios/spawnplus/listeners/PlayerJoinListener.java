package dev._2lstudios.spawnplus.listeners;

import java.util.Collection;

import org.bukkit.Location;
import org.bukkit.Sound;
import org.bukkit.configuration.Configuration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.plugin.Plugin;

import dev._2lstudios.spawnplus.config.ConfigHelper;
import dev._2lstudios.spawnplus.utilities.BukkitUtil;
import dev._2lstudios.spawnplus.config.ConfigManager;
import dev._2lstudios.spawnplus.utilities.Formatter;

public class PlayerJoinListener implements Listener {
    private ConfigManager configManager;
    private Plugin plugin;

    public PlayerJoinListener(ConfigManager configManager, Plugin plugin) {
        this.configManager = configManager;
        this.plugin = plugin;
    }

    @EventHandler(ignoreCancelled = true, priority = EventPriority.HIGHEST)
    public void onPlayerJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        Configuration config = plugin.getConfig();

        if (player.hasPermission(config.getString("join-message-permission"))) {
            event.setJoinMessage(Formatter.format(player, config.getString("messages.join")));
        } else {
            event.setJoinMessage("");
        }

        if (config.getBoolean("spawn-on-join")) {
            Configuration spawnConfig = configManager.getConfig("spawn.yml");
            Location spawn = ConfigHelper.getLocation(spawnConfig, "spawn");
            BukkitUtil.teleport(player, spawn, config.getInt("spawn-radius"));
        }

        if (player.hasPermission(config.getString("spawn-sound-permission"))) {
            Collection<String> spawnSounds = config.getStringList("spawn-sound");

            if (spawnSounds != null && !spawnSounds.isEmpty()) {
                for (String soundName : spawnSounds) {
                    try {
                        Sound sound = Sound.valueOf(soundName);

                        for (Player otherPlayer : plugin.getServer().getOnlinePlayers()) {
                            otherPlayer.playSound(otherPlayer.getLocation(), sound, 1.0f, 1.0f);
                        }
                    } catch (IllegalArgumentException ex) {
                        plugin.getLogger().warning("Tried to play sound " + soundName + " but it doesn't exist!");
                    }
                }
            }
        }

        if (config.getBoolean("spawn-firework")) {
            if (player.hasPermission(config.getString("spawn-firework-permission"))) {
                BukkitUtil.spawnFireworks(player.getLocation(), 1);
            }
        }
    }
}
