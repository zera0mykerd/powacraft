package dev._2lstudios.spawnplus.listeners;

import org.bukkit.Location;
import org.bukkit.configuration.Configuration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.Plugin;

import dev._2lstudios.spawnplus.config.ConfigHelper;
import dev._2lstudios.spawnplus.utilities.BukkitUtil;
import dev._2lstudios.spawnplus.config.ConfigManager;
import dev._2lstudios.spawnplus.utilities.Formatter;

public class PlayerQuitListener implements Listener {
    private ConfigManager configManager;
    private Plugin plugin;

    public PlayerQuitListener(ConfigManager configManager, Plugin plugin) {
        this.configManager = configManager;
        this.plugin = plugin;
    }

    @EventHandler
    public void onPlayerQuit(PlayerQuitEvent event) {
        Player player = event.getPlayer();
        Configuration config = plugin.getConfig();

        if (player.hasPermission(config.getString("quit-message-permission"))) {
            event.setQuitMessage(Formatter.format(player, config.getString("messages.quit")));
        } else {
            event.setQuitMessage("");
        }

        if (config.getBoolean("spawn-on-join")) {
            Configuration spawnConfig = configManager.getConfig("spawn.yml");
            Location spawn = ConfigHelper.getLocation(spawnConfig, "spawn");
            BukkitUtil.teleport(player, spawn, config.getInt("spawn-radius"));
        }
    }
}
