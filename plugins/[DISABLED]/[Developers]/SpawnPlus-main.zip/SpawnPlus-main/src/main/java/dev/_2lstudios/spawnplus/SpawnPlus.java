package dev._2lstudios.spawnplus;

import org.bukkit.Server;
import org.bukkit.plugin.PluginManager;
import org.bukkit.plugin.java.JavaPlugin;

import dev._2lstudios.spawnplus.commands.SetSpawnCommand;
import dev._2lstudios.spawnplus.commands.SpawnCommand;
import dev._2lstudios.spawnplus.config.ConfigManager;
import dev._2lstudios.spawnplus.listeners.EntityDamageByEntityListener;
import dev._2lstudios.spawnplus.listeners.PlayerJoinListener;
import dev._2lstudios.spawnplus.listeners.PlayerMoveListener;
import dev._2lstudios.spawnplus.listeners.PlayerQuitListener;
import dev._2lstudios.spawnplus.listeners.PlayerRespawnListener;
import dev._2lstudios.spawnplus.request.SpawnRequests;
import dev._2lstudios.spawnplus.tasks.SpawnTask;

public class SpawnPlus extends JavaPlugin {
    private static SpawnPlus instance;

    public static SpawnPlus getInstance() {
        return SpawnPlus.instance;
    }

    @Override
    public void onEnable() {
        saveDefaultConfig();

        SpawnPlus.instance = this;

        Server server = getServer();
        PluginManager pluginManager = server.getPluginManager();
        ConfigManager configManager = new ConfigManager(this);
        SpawnRequests spawnRequests = new SpawnRequests();

        getCommand("spawn").setExecutor(new SpawnCommand(configManager, this, spawnRequests));
        getCommand("setspawn").setExecutor(new SetSpawnCommand(configManager, this));

        pluginManager.registerEvents(new EntityDamageByEntityListener(this, spawnRequests), this);
        pluginManager.registerEvents(new PlayerJoinListener(configManager, this), this);
        pluginManager.registerEvents(new PlayerMoveListener(this, spawnRequests), this);
        pluginManager.registerEvents(new PlayerQuitListener(configManager, this), this);
        pluginManager.registerEvents(new PlayerRespawnListener(this, configManager), this);

        server.getScheduler().runTaskTimer(this, new SpawnTask(configManager, this, spawnRequests), 20L, 20L);
    }
}