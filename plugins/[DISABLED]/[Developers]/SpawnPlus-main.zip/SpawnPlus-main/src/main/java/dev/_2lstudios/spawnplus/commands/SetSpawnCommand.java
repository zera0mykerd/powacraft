package dev._2lstudios.spawnplus.commands;

import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.Configuration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

import dev._2lstudios.spawnplus.config.ConfigHelper;
import dev._2lstudios.spawnplus.config.ConfigManager;
import dev._2lstudios.spawnplus.utilities.Formatter;

public class SetSpawnCommand implements CommandExecutor {
    private ConfigManager configManager;
    private Plugin plugin;

    public SetSpawnCommand(ConfigManager configManager, Plugin plugin) {
        this.configManager = configManager;
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        Configuration config = plugin.getConfig();

        if (sender instanceof Player) {
            Player player = (Player) sender;

            if (sender.hasPermission("spawnplus.setspawn")) {
                YamlConfiguration spawnConfig = configManager.getConfig("spawn.yml");
                Location location = player.getLocation();

                ConfigHelper.setLocation(spawnConfig, "spawn", location);

                configManager.save(spawnConfig, "spawn.yml");
                sender.sendMessage(Formatter.format(config.getString("messages.set-spawn")));
            } else {
                sender.sendMessage(Formatter.format(config.getString("messages.permission")));
            }
        } else {
            sender.sendMessage(Formatter.format(config.getString("messages.console")));
        }

        return true;
    }
}
