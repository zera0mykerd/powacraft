package dev._2lstudios.spawnplus.config;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.configuration.Configuration;
import org.bukkit.util.Vector;

public class ConfigHelper {
    public static Location getLocation(Configuration config, String key) {
        Vector vector = config.getVector(key + ".vector", null);
        String worldName = config.getString(key + ".world", null);
        float yaw = (float) config.getDouble(key + ".yaw");
        float pitch = (float) config.getDouble(key + ".pitch");

        if (vector != null && worldName != null) {
            return new Location(Bukkit.getWorld(worldName), vector.getX(), vector.getY(), vector.getZ(), yaw, pitch);
        }

        return null;
    }

    public static void setLocation(Configuration config, String key, Location location) {
        Vector vector = location.toVector();
        String worldName = location.getWorld().getName();
        float pitch = location.getPitch();
        float yaw = location.getYaw();

        config.set(key + ".vector", vector);
        config.set(key + ".world", worldName);
        config.set(key + ".pitch", pitch);
        config.set(key + ".yaw", yaw);
    }
}
