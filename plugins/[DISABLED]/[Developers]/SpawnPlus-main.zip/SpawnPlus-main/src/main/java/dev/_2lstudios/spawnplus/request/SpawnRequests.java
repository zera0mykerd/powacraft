package dev._2lstudios.spawnplus.request;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import org.bukkit.entity.Player;

public class SpawnRequests {
    private Map<UUID, SpawnRequest> spawnRequests = new HashMap<>();

    public SpawnRequest getSpawnRequest(UUID uuid) {
        return spawnRequests.getOrDefault(uuid, null);
    }

    public SpawnRequest getSpawnRequest(Player player) {
        return getSpawnRequest(player.getUniqueId());
    }

    public void removeSpawnRequest(UUID uuid) {
        spawnRequests.remove(uuid);
    }

    public void removeSpawnRequest(Player player) {
        removeSpawnRequest(player.getUniqueId());
    }

    public void addSpawnRequest(SpawnRequest spawnRequest) {
        spawnRequests.put(spawnRequest.getPlayer().getUniqueId(), spawnRequest);
    }

    public Map<UUID, SpawnRequest> getSpawnRequests() {
        return spawnRequests;
    }
}
