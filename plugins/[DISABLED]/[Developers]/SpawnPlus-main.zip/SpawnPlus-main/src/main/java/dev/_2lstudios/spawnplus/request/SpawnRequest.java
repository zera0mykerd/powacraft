package dev._2lstudios.spawnplus.request;

import org.bukkit.entity.Player;

public class SpawnRequest {
    private Player player;
    private int time;

    public SpawnRequest(Player player, int time) {
        this.player = player;
        this.time = time;
    }

    public Player getPlayer() {
        return player;
    }

    public int tick() {
        return --time;
    }
}
