package dev._2lstudios.spawnplus.tasks;

import java.util.Iterator;
import java.util.Map;
import java.util.UUID;

import org.bukkit.Location;
import org.bukkit.configuration.Configuration;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

import dev._2lstudios.spawnplus.config.ConfigHelper;
import dev._2lstudios.spawnplus.request.SpawnRequest;
import dev._2lstudios.spawnplus.request.SpawnRequests;
import dev._2lstudios.spawnplus.config.ConfigManager;
import dev._2lstudios.spawnplus.utilities.BukkitUtil;
import dev._2lstudios.spawnplus.utilities.Formatter;

public class SpawnTask implements Runnable {
    private ConfigManager configManager;
    private Plugin plugin;
    private SpawnRequests spawnRequests;

    public SpawnTask(ConfigManager configManager, Plugin plugin, SpawnRequests spawnRequests) {
        this.configManager = configManager;
        this.plugin = plugin;
        this.spawnRequests = spawnRequests;
    }

    @Override
    public void run() {
        Map<UUID, SpawnRequest> spawnRequestsMap = spawnRequests.getSpawnRequests();

        if (!spawnRequestsMap.isEmpty()) {
            Iterator<SpawnRequest> iterator = spawnRequestsMap.values().iterator();
            Configuration spawnConfig = configManager.getConfig("spawn.yml");
            Configuration config = plugin.getConfig();
            Location spawn = ConfigHelper.getLocation(spawnConfig, "spawn");
            String teleportedMessage = Formatter.format(config.getString("messages.teleported"));
            int radius = config.getInt("spawn-radius");

            while (iterator.hasNext()) {
                SpawnRequest spawnRequest = iterator.next();
                int remaining = spawnRequest.tick();

                if (remaining <= 0) {
                    iterator.remove();

                    Player player = spawnRequest.getPlayer();

                    BukkitUtil.teleport(player, spawn, radius);
                    player.sendMessage(teleportedMessage);
                }
            }
        }
    }
}