package dev._2lstudios.spawnplus.commands;

import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.Configuration;
import org.bukkit.entity.Player;

import dev._2lstudios.spawnplus.SpawnPlus;
import dev._2lstudios.spawnplus.config.ConfigManager;
import dev._2lstudios.spawnplus.request.SpawnRequest;
import dev._2lstudios.spawnplus.request.SpawnRequests;
import dev._2lstudios.spawnplus.utilities.Formatter;

public class SpawnCommand implements CommandExecutor {
    private ConfigManager configManager;
    private SpawnPlus spawnPlus;
    private SpawnRequests spawnRequests;

    public SpawnCommand(ConfigManager configManager, SpawnPlus spawnPlus, SpawnRequests spawnRequests) {
        this.configManager = configManager;
        this.spawnPlus = spawnPlus;
        this.spawnRequests = spawnRequests;
    }

    private boolean arePlayersNearby(Player player, int distance) {
        Location location = player.getLocation();

        for (Player player1 : player.getWorld().getPlayers()) {
            if (player != player1 && location.distance(player1.getLocation()) <= distance) {
                return true;
            }
        }

        return false;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        Configuration config = spawnPlus.getConfig();

        if (sender instanceof Player) {
            Player player = (Player) sender;

            if (spawnRequests.getSpawnRequest(player) == null) {
                String spawnPermission = config.getString("spawn-permission");

                if (spawnPermission.isEmpty() || player.hasPermission(spawnPermission)) {
                    Configuration spawnConfig = configManager.getConfig("spawn.yml");

                    if (spawnConfig.contains("spawn")) {
                        int warmup;

                        if (arePlayersNearby(player, 64)) {
                            warmup = 8;
                        } else {
                            warmup = 1;
                        }

                        spawnRequests.addSpawnRequest(new SpawnRequest(player, warmup));
                        player.sendMessage(Formatter.format(player,
                                config.getString("messages.teleporting").replace("%time%", String.valueOf(warmup))));
                    } else {
                        player.sendMessage(Formatter.format(player,
                                config.getString("messages.no-spawn")));
                    }
                } else {
                    player.sendMessage(Formatter.format(player, config.getString("messages.permission")));
                }
            } else {
                player.sendMessage(Formatter.format(player, config.getString("messages.already-teleporting")));
            }
        } else {
            sender.sendMessage(Formatter.format(config.getString("messages.console")));
        }

        return true;
    }
}
