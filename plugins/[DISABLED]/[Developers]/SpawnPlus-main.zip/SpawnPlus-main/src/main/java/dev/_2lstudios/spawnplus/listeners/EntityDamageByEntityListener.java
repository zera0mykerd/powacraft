package dev._2lstudios.spawnplus.listeners;

import org.bukkit.configuration.Configuration;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;

import dev._2lstudios.spawnplus.SpawnPlus;
import dev._2lstudios.spawnplus.request.SpawnRequests;
import dev._2lstudios.spawnplus.utilities.Formatter;

public class EntityDamageByEntityListener implements Listener {
    private SpawnPlus spawnPlus;
    private SpawnRequests spawnRequests;

    public EntityDamageByEntityListener(SpawnPlus spawnPlus, SpawnRequests spawnRequests) {
        this.spawnPlus = spawnPlus;
        this.spawnRequests = spawnRequests;
    }

    @EventHandler(ignoreCancelled = true)
    public void onEntityDamageByEntity(EntityDamageByEntityEvent event) {
        Entity damaged = event.getEntity();

        if (damaged instanceof Player) {
            Player player = (Player) damaged;

            if (spawnRequests.getSpawnRequest(player) != null) {
                Configuration config = spawnPlus.getConfig();

                spawnRequests.removeSpawnRequest(player);
                player.sendMessage(Formatter.format(player,
                        config.getString("messages.movement")));
            }
        }
    }
}
