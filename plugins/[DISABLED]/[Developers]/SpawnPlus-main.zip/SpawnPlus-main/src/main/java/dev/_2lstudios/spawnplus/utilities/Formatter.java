package dev._2lstudios.spawnplus.utilities;

import com.iridium.iridiumcolorapi.IridiumColorAPI;

import org.bukkit.entity.Player;

public class Formatter {
    public static String format(Player player, String text) {
        if (player != null) {
            text = text.replace("%playername%", player.getName()).replace("%displayname%",
            player.getDisplayName());
        }

        return IridiumColorAPI.process(text);
    }

    public static String format(String text) {
        return format(null, text);
    }
}
