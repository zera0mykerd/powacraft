package dev._2lstudios.spawnplus.listeners;

import org.bukkit.Location;
import org.bukkit.configuration.Configuration;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.plugin.Plugin;

import dev._2lstudios.spawnplus.config.ConfigHelper;
import dev._2lstudios.spawnplus.config.ConfigManager;
import dev._2lstudios.spawnplus.utilities.BukkitUtil;

public class PlayerRespawnListener implements Listener {
    private Plugin plugin;
    private ConfigManager configManager;

    public PlayerRespawnListener(Plugin plugin, ConfigManager configManager) {
        this.plugin = plugin;
        this.configManager = configManager;
    }

    @EventHandler
    public void onPlayerRespawn(PlayerRespawnEvent event) {
        Configuration config = plugin.getConfig();

        if (config.getBoolean("spawn-on-death") && (config.getBoolean("spawn-bypass-bed") || !event.isBedSpawn())) {
            Configuration spawnConfig = configManager.getConfig("spawn.yml");
            Location spawn = ConfigHelper.getLocation(spawnConfig, "spawn");

            if (spawn != null) {
                event.setRespawnLocation(BukkitUtil.getRandomizedLocation(spawn, config.getInt("spawn-radius")));
            }
        }
    }
}
