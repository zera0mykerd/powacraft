package me.grax.jbytemod.analysis.decompiler.code.ast;

public enum EndBlock {
    CONTINUE, BREAK;
}
