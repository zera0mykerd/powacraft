package me.grax.jbytemod.analysis.decompiler.syntax.nodes;

import me.grax.jbytemod.analysis.decompiler.code.ast.Expression;

import java.util.ArrayList;

public class NodeList extends ArrayList<Expression> {

    private static final long serialVersionUID = 1L;

}
