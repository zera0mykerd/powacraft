package de.xbrowniecodez.jbytemod.procyon;

public class CustomBuffer {

}
