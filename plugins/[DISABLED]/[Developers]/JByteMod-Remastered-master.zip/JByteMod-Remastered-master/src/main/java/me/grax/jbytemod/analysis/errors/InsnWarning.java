package me.grax.jbytemod.analysis.errors;

public class InsnWarning extends Mistake {

    public InsnWarning(String desc) {
        super(desc);
    }

}
