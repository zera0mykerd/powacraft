package me.grax.jbytemod.analysis.errors;

public class InsnError extends Mistake {

    public InsnError(String desc) {
        super(desc);
    }

}
