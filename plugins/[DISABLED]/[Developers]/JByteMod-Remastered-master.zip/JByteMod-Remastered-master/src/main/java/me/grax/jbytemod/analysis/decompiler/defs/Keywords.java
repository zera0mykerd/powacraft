package me.grax.jbytemod.analysis.decompiler.defs;

public class Keywords {
    public static final String RETURN = "return";
    public static final String THROW = "throw";
    public static final String NULL = "null";
    //TODO add other keywords
}
