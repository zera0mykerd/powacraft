package hakery.club.raccscanner.results.util;

public enum Obfuscator {
    PARAMORPHISM,
    ALLATORI,
    STRINGER,
    DASHO,
    OTHER
}