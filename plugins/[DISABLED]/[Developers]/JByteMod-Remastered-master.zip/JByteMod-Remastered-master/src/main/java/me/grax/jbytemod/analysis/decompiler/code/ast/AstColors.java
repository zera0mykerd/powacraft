package me.grax.jbytemod.analysis.decompiler.code.ast;

public class AstColors {
    public static final String edgeColor = "#111111";
    public static final String jumpColor = "#39698a";

    public static final String jumpColorGreen = "#388a47";
    public static final String jumpColorRed = "#8a3e38";
    public static final String jumpColorPurple = "#71388a";
    public static final String jumpColorPink = "#ba057a"; //8a386d

}
