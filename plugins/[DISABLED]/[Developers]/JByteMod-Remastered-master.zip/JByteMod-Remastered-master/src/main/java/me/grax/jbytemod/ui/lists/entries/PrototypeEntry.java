package me.grax.jbytemod.ui.lists.entries;

public class PrototypeEntry extends InstrEntry {

    public PrototypeEntry() {
        super(null, null);
    }

    @Override
    public String toString() {
        return " ";
    }

    @Override
    public String toEasyString() {
        return " ";
    }

    @Override
    public String getHint() {
        return null;
    }
}
