package me.grax.jbytemod.analysis.decompiler.struct.exception;

public class StackException extends RuntimeException {
    private static final long serialVersionUID = 1L;

    public StackException(String string) {
        super(string);
    }

}
