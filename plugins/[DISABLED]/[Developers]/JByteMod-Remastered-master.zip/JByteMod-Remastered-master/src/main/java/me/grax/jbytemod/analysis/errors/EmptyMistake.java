package me.grax.jbytemod.analysis.errors;

public class EmptyMistake extends Mistake {
    public EmptyMistake() {
        super(" ");
    }
}
