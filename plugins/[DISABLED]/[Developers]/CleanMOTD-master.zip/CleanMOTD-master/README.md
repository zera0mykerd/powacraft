# CleanMOTD
Simple and light plugin to manage the motd of your server.
