# ChatSentinel
Light plugin to prevent Spam/Swearing on your Spigot/Bungee server.
