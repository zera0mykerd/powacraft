# ChatImage
Send images in Minecraft! Download [here](https://www.spigotmc.org/resources/chatimage-send-images-in-minecraft.95842/).

<img src="https://i.imgur.com/yqqzSVJ.gif" width="800">
<img src="https://bstats.org/signatures/bukkit/ChatImage.svg" width="800">

### Click [here](https://www.spigotmc.org/resources/chatimage-send-images-in-minecraft.95842/) for more information.
