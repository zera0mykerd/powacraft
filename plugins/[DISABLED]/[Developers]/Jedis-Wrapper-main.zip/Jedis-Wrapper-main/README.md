# Jedis Wrapper

Redis client for java (Jedis) wrapped for Bukkit/Spigot and BungeeCord.