package dev._2lstudios.jediswrapper;

import org.bukkit.plugin.java.JavaPlugin;

public class JedisWrapperBukkit extends JavaPlugin {
}
