package dev._2lstudios.jediswrapper;

import net.md_5.bungee.api.plugin.Plugin;

public class JedisWrapperBungee extends Plugin {
}
