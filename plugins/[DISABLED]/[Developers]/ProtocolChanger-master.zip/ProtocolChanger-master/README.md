# ProtocolChanger
Multiplayer で通知(?)される ProtocolName を変更するものです。
 
・Spigot での使用

　前提で ProtocolLib が必要です。
 
・BungeeCord での使用

　前提プラグインは不要です。
 
# Download
 Binaries can be found at `target` folder.
