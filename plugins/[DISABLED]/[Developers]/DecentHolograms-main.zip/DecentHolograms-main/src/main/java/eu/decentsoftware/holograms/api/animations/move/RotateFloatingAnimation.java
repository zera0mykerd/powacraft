package eu.decentsoftware.holograms.api.animations.move;

public class RotateFloatingAnimation {
    // Just play both animations for a single hologram object.
}
