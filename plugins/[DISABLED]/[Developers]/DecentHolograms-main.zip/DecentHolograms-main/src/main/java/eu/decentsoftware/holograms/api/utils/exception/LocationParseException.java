package eu.decentsoftware.holograms.api.utils.exception;

public class LocationParseException extends Exception {

    public LocationParseException(String message) {
        super(message);
    }

}
