package eu.decentsoftware.holograms.api.holograms.enums;

public enum EnumFlag {
	DISABLE_PLACEHOLDERS,
	DISABLE_UPDATING,
	DISABLE_ANIMATIONS,
	DISABLE_ACTIONS
}
