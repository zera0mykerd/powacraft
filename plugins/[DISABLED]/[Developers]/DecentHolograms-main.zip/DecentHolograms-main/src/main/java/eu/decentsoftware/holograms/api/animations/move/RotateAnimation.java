package eu.decentsoftware.holograms.api.animations.move;

public class RotateAnimation {
}
