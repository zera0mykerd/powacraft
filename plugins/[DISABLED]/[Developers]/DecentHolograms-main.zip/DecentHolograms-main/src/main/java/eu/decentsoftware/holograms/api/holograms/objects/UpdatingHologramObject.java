package eu.decentsoftware.holograms.api.holograms.objects;

import eu.decentsoftware.holograms.api.Settings;
import lombok.Getter;
import lombok.Setter;
import org.bukkit.Location;

@Getter
@Setter
public abstract class UpdatingHologramObject extends HologramObject {

    /*
     *	Fields
     */

    protected int displayRange = Settings.DEFAULT_DISPLAY_RANGE.getValue();
    protected int updateRange = Settings.DEFAULT_UPDATE_RANGE.getValue();
    protected volatile int updateInterval = Settings.DEFAULT_UPDATE_INTERVAL.getValue();

    /*
     *	Constructors
     */

    public UpdatingHologramObject(Location location) {
        super(location);
    }

}
