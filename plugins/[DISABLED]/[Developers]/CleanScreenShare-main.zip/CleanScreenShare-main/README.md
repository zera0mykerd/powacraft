# CleanScreenShare
CleanScreenShare is a hack control plugin, made for networks.
