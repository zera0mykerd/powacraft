Hi!

Thanks for using the config! It is built up by community input. If you have any issues with the config, Please let me know!

There are currently three config types, All configs will notify and cancel their attempt to cheat:

Auto-Ban: This config works by banning users that get a high violation in a specific check. There are also Temp-Bans and Kicks included in this config.

Auto-Kick: This config works by kicking users who get a high violation in a specific check. No bans are present.

Notify and Cancel only: This config works by only notifying staff when a user has violated a check. No kicks and bans are present. It will still stop their attempt to cheat.

To install a config, drag one config you want into your NoCheatPlus folder. It should replace the existing config. If you have not already installed NoCheatPlus, click on the link and download the latest build of NoCheatPlus. Restart your server and a NoCheatPlus folder should appear. Then you can drag over the new config. Once you have dragged over the new config, you can restart your server or do /ncp reload in console. 

Let me know if you have any more questions. Thanks!

Helpful Links:
Questions or Comments? Ask me here: https://goo.gl/Du4BpY
Take the survey: https://docs.google.com/forms/d/e/1FAIpQLSfZmWyAuhxA-gOac1zpeGh1kFrJlG_0Ipjq9B014PF1XlQm1g/viewform