Config is currently under beta. 

To install the config, replace the old PNCP config with the old one and restart your server. 

Most checks will ban at a high violation. Please report any false positives to the developer.

Install the EN file in the langs folder.

Link to plugin: https://www.spigotmc.org/resources/pncp-a-nocheatplus-addition-1-7-10-1-11-support-1000-downloads.37941/
Report an issue: https://github.com/HorizonCode/PNCP/issues