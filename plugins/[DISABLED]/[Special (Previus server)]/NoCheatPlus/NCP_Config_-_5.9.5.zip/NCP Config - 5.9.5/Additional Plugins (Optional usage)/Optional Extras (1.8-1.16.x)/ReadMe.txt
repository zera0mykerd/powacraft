CompatNoCheatPlus:
  mcMMO:
  Block breaks by abilities should lead to no or almost no alerts anymore.
  Fighting alerts should be reduced.
  Citizens 2:
  NPCs no longer generate check alerts.
  Cancel all check failures for players that are not real players. This should handle a range of NPC creation techniques in general, as exist with Citizens 1.
  (Experts: good bit of it is configurable.)
  Block breaking and block placing: Plugins that break or place many blocks "in the name of a player" have a better chance to be made compatible by adapting the configuration. Defaults are set for MachinaCraft.
  Bukkit player speed API: Set the fly/walk speeds globally and let NoCheatPlus deal with the rest. (Needs to be enabled in the configuration.)

NCPDragDown:
  Ideal for gamemode with floating blocks i.e Skyblocks, Skywars, Parkour, etc
  Simply, rather than teleporting players to the last solid block they stood on when setting off a check, they are dragged down. Think, doing parkour and if you fail a jump, a hacked client can abuse ncp's set back policy and teleport back to the last jump. The plugin would continue to keep the player falling rather than teleporting them back up.
  Pretty much what you see in this video: https://www.youtube.com/watch?v=BM8ostRmbDo