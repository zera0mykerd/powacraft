<?php

/**
 *	CHATBOX MODULE
 *	By Xemah | https://xemah.com
 *
**/

define('PAGE', 'chat');
header('Content-Type: application/json; charset=UTF-8');

$settings = ChatboxModule::getSettings($cache);

require(__DIR__ . '/../classes/Chatbox.php');
$chatbox = new Chatbox($user, $language, $settings);

$input = file_get_contents('php://input');
$input = json_decode($input, true);

$action = null;
if (isset($input['action'])) {
	$action = $input['action'];
}

$data = $chatbox->handleAction($action, $input);
$response = [
	'success' => is_null($data) ? false : true,
	'data' => is_null($data) ? [] : $data
];

echo json_encode($response, JSON_PRETTY_PRINT);