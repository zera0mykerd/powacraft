<?php

/**
 *	CHATBOX MODULE
 *	By Xemah | https://xemah.com
 *
**/

if (!$user->handlePanelPageLoad(ChatboxModule::$PANEL_PERMISSION)) {
	require_once(ROOT_PATH . '/403.php');
	die();
};

define('PAGE', 'panel');
define('PARENT_PAGE', 'chatbox');
define('PANEL_PAGE', 'chatbox');

$page_title = ChatboxModule::getLanguage('general', 'settings');
require_once(ROOT_PATH . '/core/templates/backend_init.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

	if (!Token::check($_POST['token'])) {
		Session::flash('error', ChatboxModule::getLanguage('general', 'errorToken'));
		Redirect::to(URL::build('/panel/chatbox'));
	}

	$cache->setCache(ChatboxModule::$CACHE);

	$titleInput = $_POST['title'];
	$cache->store('title', isset($titleInput) ? $titleInput : 'Chatbox');

	$positionInput = $_POST['position'];
	$cache->store('position', isset($positionInput) ? $positionInput : 'top');

	$pagesInput = $_POST['pages'];
	$cache->store('pages', isset($pagesInput) ? json_encode($pagesInput) : '[]');

	$guestsInput = $_POST['guests'];
	$cache->store('guests', isset($guestsInput) ? $guestsInput : '1');

	$soundsInput = $_POST['sounds'];
	$cache->store('sounds', isset($soundsInput) ? $soundsInput : '1');

	$fetchLimitInput = $_POST['fetchLimit'];
	$cache->store('fetchLimit', isset($fetchLimitInput) ? $fetchLimitInput : '25');

	$groupIcons = $_POST['groupIcons'];
	$cache->store('groupIcons', isset($groupIcons) ? $groupIcons : '1');

	Session::flash('success', ChatboxModule::getLanguage('general', 'settingsUpdated'));
	Redirect::to(URL::build('/panel/chatbox'));

}

$settings = ChatboxModule::getSettings($cache);

$pagesQuery = array_filter($pages->returnPages(), function($p) {
	return $p['widgets'] == true;
});

$pagesOptions = [];
foreach ($pagesQuery as $item) {
	$pagesOptions[$item['name']] = ucfirst($item['name']);
}

if (Session::exists('success')) {
	$smarty->assign('SUCCESS', Session::flash('success'));
}

if (Session::exists('error')) {
	$smarty->assign('ERROR', Session::flash('error'));
}

$smarty->assign([
	'PAGE_TITLE' => $page_title,
	'PAGES_OPTIONS' => $pagesOptions,
	'SETTINGS' => $settings,
	'CHATBOX_LANGUAGE' => ChatboxModule::getLanguage(),
	'TOKEN' => Token::get(),
]);

Module::loadPage($user, $pages, $cache, $smarty, [$navigation, $cc_nav, $staffcp_nav], $widgets, $template);

$template->onPageLoad();
require(ROOT_PATH . '/core/templates/panel_navbar.php');

array_push($smarty->security_policy->secure_dir, __DIR__);

try {
	$template->displayTemplate('chatbox.tpl', $smarty);
} catch (Exception $e) {
	$template->displayTemplate(__DIR__ . '/chatbox.tpl', $smarty);
}