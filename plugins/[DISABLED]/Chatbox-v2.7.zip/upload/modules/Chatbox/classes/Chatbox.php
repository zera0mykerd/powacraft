<?php

/**
 *	CHATBOX MODULE
 *	By Xemah | https://xemah.com
 *
**/

class Chatbox
{
	public function __construct($user, $language, $settings)
	{
		$this->user = $user;
		$this->language = $language;
		$this->settings = $settings;
		$this->chatLogTable = 'chat_logs';
		$this->timeago = new TimeAgo(TIMEZONE);
		$this->currentTime = time();
	}

	public function fetchMessages()
	{
		if (!$this->user->isLoggedIn() && $this->settings['guests'] != '1') {
			return null;
		}

		if ($this->user->isLoggedIn() && !$this->user->hasPermission(ChatboxModule::$PERMISSION)) {
			return null;
		}

		$data = [];
		
		try {

			$messagesQuery = DB::getInstance()->orderAll($this->chatLogTable, 'message_timestamp', 'ASC')->results();
			$messagesQuery = array_slice($messagesQuery, $this->settings['fetchLimit'] * -1);

		} catch (Exception $e) {
			return null;
		}

		foreach ($messagesQuery as $message) {

			$author = new User($message->author_id);

			$canModerate = false;
			if ($this->user->isLoggedIn() && ($this->user->hasPermission(ChatboxModule::$MODERATION_PERMISSION) || $author->data()->id === $this->user->data()->id)) {
				$canModerate = true;
			}

			$data[] = [
				'id' => $message->id,
				'content' => $this->parseMentions($message->message_content),
				'time' => date('d M Y, h:i A', $message->message_timestamp),
				'timeAgo' => $this->timeago->inWords($message->message_timestamp, $this->language),
				'authorId' => $message->author_id,
				'authorUsername' => $author->getDisplayname(true),
				'authorAvatar' => $author->getAvatar(),
				'authorProfile' => $author->getProfileURL(),
				'authorStyle' => $author->getGroupStyle(),
				'authorColor' => $author->getMainGroup()->group_username_color,
				'authorGroup' => $author->getMainGroup()->name,
				'authorGroupFirstLetter' => strtoupper($author->getMainGroup()->name[0]),
				'canModerate' => $canModerate
			];

		}
		
		return $data;
	}

	
	public function getChanges($clientData)
	{
		if (!$this->user->isLoggedIn() && $this->settings['guests'] != '1') {
			return null;
		}

		if ($this->user->isLoggedIn() && !$this->user->hasPermission(ChatboxModule::$PERMISSION)) {
			return null;
		}

		$data = [
			'newMessages' => [],
			'removedMessages' => []
		];

		$minId = 0;
		if (!empty($clientData)) {
			$minId = min($clientData);
		}

		try {

			$messagesQuery = DB::getInstance()->get($this->chatLogTable, ['id', '>=', $minId])->results();
			$messagesQueryIds = array_map(function($element) { return $element->id; }, $messagesQuery);

		} catch (Exception $e) {
			return null;
		}

		$newMessages = array_filter($messagesQuery, function($element) use ($clientData) {
			return !(in_array($element->id, $clientData));
		});

		foreach ($newMessages as $message) {

			$author = new User($message->author_id);

			$canModerate = false;
			if ($this->user->isLoggedIn() && ($this->user->hasPermission(ChatboxModule::$MODERATION_PERMISSION) || $author->data()->id === $this->user->data()->id)) {
				$canModerate = true;
			}

			$data['newMessages'][] = [
				'id' => $message->id,
				'content' => $this->parseMentions($message->message_content),
				'time' => date('d M Y, h:i A', $message->message_timestamp),
				'timeAgo' => $this->timeago->inWords($message->message_timestamp, $this->language),
				'authorId' => $message->author_id,
				'authorUsername' => $author->getDisplayname(true),
				'authorAvatar' => $author->getAvatar(),
				'authorProfile' => $author->getProfileURL(),
				'authorStyle' => $author->getGroupClass(),
				'authorColor' => $author->getMainGroup()->group_username_color,
				'authorGroup' => $author->getMainGroup()->name,
				'authorGroupFirstLetter' => strtoupper($author->getMainGroup()->name[0]),
				'canModerate' => $canModerate
			];

		}

		$data['removedMessages'] = array_values(array_filter($clientData, function($element) use ($messagesQueryIds) {
			return !(in_array($element, $messagesQueryIds));
		}));

		return $data;
	}

	public function sendMessage($messageContent)
	{
		if (!$this->user->isLoggedIn() || !$this->user->hasPermission(ChatboxModule::$MESSAGE_PERMISSION)) {
			return null;
		}

		$messageContent = Output::getClean($messageContent);
		if (empty($messageContent)) {
			return null;
		}

		try {

			DB::getInstance()->insert($this->chatLogTable, [
				'author_id' => $this->user->data()->id,
				'message_content' => $messageContent,
				'message_timestamp' => $this->currentTime
			]);

		} catch (Exception $e) {
			return null;
		}
		
		$author = $this->user;

		$canModerate = false;
		if ($this->user->isLoggedIn() && ($this->user->hasPermission(ChatboxModule::$MODERATION_PERMISSION) || $author->data()->id === $this->user->data()->id)) {
			$canModerate = true;
		}

		$data = [
			'id' => DB::getInstance()->lastId(),
			'content' => $this->parseMentions($messageContent),
			'time' => date('d M Y, h:i A', $this->currentTime),
			'timeAgo' => $this->timeago->inWords($this->currentTime, $this->language),
			'authorId' => $author->data()->id,
			'authorUsername' => $author->getDisplayname(true),
			'authorAvatar' => $author->getAvatar(),
			'authorProfile' => $author->getProfileURL(),
			'authorStyle' => $author->getGroupClass(),
			'authorColor' => $author->getMainGroup()->group_username_color,
			'authorGroup' => $author->getMainGroup()->name,
			'authorGroupFirstLetter' => strtoupper($author->getMainGroup()->name[0]),
			'canModerate' => $canModerate
		];

		return $data;
	}

	public function removeMessage($messageId)
	{
		if (!$this->user->isLoggedIn()) {
			return null;
		}

		if (empty($messageId)) {
			return null;
		}

		$messageQuery = DB::getInstance()->get($this->chatLogTable, ['id', '=', $messageId])->results();
		if (empty($messageQuery)) {
			return null;
		}

		$messageQuery = $messageQuery[0];
		
		if (!$this->user->hasPermission(ChatboxModule::$MODERATION_PERMISSION) && $messageQuery->author_id !== $this->user->data()->id) {
			return null;
		}

		try {
			DB::getInstance()->delete($this->chatLogTable, ['id', '=', $messageQuery->id]);
		} catch (Exception $e) {
			return null;
		}

		return $messageQuery;
	}

	public function parseMentions($string)
	{
		preg_match_all('/(^|\s)(@\w+)/', $string, $matches);
		$matches = array_unique($matches[2]);

		foreach ($matches as $match) {
			$username = ltrim($match, '@');
			$mentionedUser = new User($username, 'username');
			if ($mentionedUser->exists()) {
				$html = "<a href=\"{$mentionedUser->getProfileURL()}\" target=\"_blank\" class=\"chat-user-mention\" style=\"{$mentionedUser->getGroupClass()}\">@{$mentionedUser->getDisplayname(true)}</a>";
				$string = str_replace($match, $html, $string);
			}
		}

		return $string;
	}

	public function handleAction($action = null, $input = [])
	{
		if (!$action) {
			return null;
		}

		if ($action === 'fetchMessages') {
			return $this->fetchMessages();
		}

		if ($action === 'sendMessage') {
			$messageContent = $input['messageContent'];
			return $this->sendMessage($messageContent);
		}

		if ($action === 'removeMessage') {
			$messageId = $input['messageId'];
			return $this->removeMessage($messageId);
		}

		if ($action === 'getChanges') {
			$data = $input['data'];
			return $this->getChanges($data);
		}
	}
}