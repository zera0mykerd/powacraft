/**
 *	MADE BY XEMAH
 *	https://xemah.com
 *
**/

class Chatbox {

	constructor(chatbox) {

		this.chatbox = chatbox;
		this.endpoint = `${siteURL}api/chat`;
		this.delay = 1500;
		this.data = [];
		this.busy = false;

		this.init();

	}

	async init() {

		let chatboxContainerElement = document.querySelector(this.chatbox.elements.containerTop);
		if (this.chatbox.position === 'bottom') {
			chatboxContainerElement = document.querySelector(this.chatbox.elements.containerBottom);
		}
		
		let chatboxTemplate = this.chatbox.templates.container;
		chatboxTemplate = this.decodeVariables(chatboxTemplate, Object.assign({}, this.chatbox.locale, {
			title: this.chatbox.title,
			position: this.chatbox.position,
		}));
		
		let chatboxElement = document.createElement('div');
		chatboxElement.id = 'chatboxContainer';
		chatboxElement.innerHTML = chatboxTemplate;
		
		let chatboxStyle = document.createElement('style');
		chatboxStyle.innerHTML = this.chatbox.style;
		chatboxElement.appendChild(chatboxStyle);

		if (this.chatbox.position === 'bottom') {
			chatboxContainerElement.appendChild(chatboxElement);
		} else {
			chatboxContainerElement.insertBefore(chatboxElement, chatboxContainerElement.firstChild);
		}
		
		await this.fetchChatMessages();

		const chatboxLogElement = document.querySelector(this.chatbox.elements.log);
		chatboxLogElement.scrollTop = chatboxLogElement.scrollHeight;
	
		const chatboxFormElement = document.querySelector(this.chatbox.elements.form);
		if (this.chatbox.inputAllowed) {
			chatboxFormElement.classList.remove('disabled');
		}

		this.listenChanges();

		const chatboxInputElement = document.querySelector(this.chatbox.elements.input);
		chatboxFormElement.addEventListener('submit', async (event) => {
			event.preventDefault();
			chatboxInputElement.classList.add('disabled');
			await this.sendMessage(chatboxInputElement.value);
			chatboxInputElement.value = '';
			chatboxInputElement.classList.remove('disabled');
		});

		chatboxLogElement.addEventListener('click', async (event) => {
			const element = event.target
			if (element.id.startsWith('chatMessageRemove')) {
				event.preventDefault();
				const chatMessageID = element.id.split('-').pop();
				const chatMessageElement = chatboxElement.querySelector('#chatMessage-' + chatMessageID);
				chatMessageElement.classList.add('disabled');
				await this.deleteMessage(chatMessageID);
			}
		});

	}

	async fetchChatMessages() {
	
		const chatLogElem = document.querySelector(this.chatbox.elements.log);
		if (!chatLogElem) {
			return null;
		}
	
		let response = await fetch(this.endpoint, {
			method: 'post',
			body: JSON.stringify({
				action: 'fetchMessages',
			})
		});

		response = await response.json();
		if (!response.success) {
			return null;
		}

		if (response.data.length > 0) {
			this.addMessages(response.data);
		} else {
			chatLogElem.innerHTML = this.chatbox.locale.noMessages;
		}
	
	}

	async sendMessage(messageContent) {
	
		let response = await fetch(this.endpoint, {
			method: 'post',
			body: JSON.stringify({
				action: 'sendMessage',
				messageContent: messageContent
			})
		});

		response = await response.json();
		if (!response.success) {
			return null;
		}

		this.addMessages([response.data]);

		return response.data;

	}

	async deleteMessage(messageId) {
		
		let response = await fetch(this.endpoint, {
			method: 'post',
			body: JSON.stringify({
				action: 'removeMessage',
				messageId: messageId
			})
		});

		response = await response.json();
		if (!response.success) {
			return null;
		}
		
		this.removeMessages([response.data.messageId]);

		return response.data;

	}

	addMessages(messages) {
		
		let chatLog = '';

		const chatLogElem = document.querySelector(this.chatbox.elements.log);
		if (!chatLogElem) {
			return null;
		}
	
		for (let message of messages) {

			let messageActions = '';
			if (message.canModerate) {
				messageActions = `<a href="#" id="chatMessageRemove-${message.id}">Remove</a>`;
			}
	
			let messageItemTemplate = this.chatbox.templates.item;
			messageItemTemplate = this.decodeVariables(messageItemTemplate, Object.assign({}, this.chatbox.locale, {
				messageId: message.id,
				messageContent: message.content,
				messageActions: messageActions,
				messageTime: message.time,
				timeAgo: message.timeAgo,
				authorId: message.authorId,
				authorUsername: message.authorUsername,
				authorAvatar: message.authorAvatar,
				authorProfile: message.authorProfile,
				authorStyle: message.authorStyle,
				authorColor: message.authorColor,
				authorGroup: message.authorGroup,
				authorGroupFirstLetter: this.chatbox.groupIconsEnabled ? message.authorGroupFirstLetter : '',
			}));
	
			if (this.data.filter((element) => element.messageId === message.id).length === 0) {
				this.data.push(message);
			}

			if (!chatLogElem.querySelector(`#chatMessage-${message.id}`)) {
				chatLog += messageItemTemplate;
			}
	
		}
	
		if (!chatLogElem.querySelector('[id^="chatMessage"]')) {
			chatLogElem.innerHTML = '';
		}

		let scroll = false;
		if (chatLogElem.scrollTop > (chatLogElem.scrollHeight - chatLogElem.offsetHeight - 25)) {
			scroll = true;
		}

		if (chatLog !== '') {
			chatLogElem.innerHTML += chatLog;
			if (scroll) {
				chatLogElem.scrollTop = chatLogElem.scrollHeight;
			}
		}

	}

	removeMessages(messages) {
		
		for (let messageId of messages) {

			this.data = this.data.filter((element) => element.id !== messageId);

			const chatLogElem = document.querySelector(this.chatbox.elements.log);
			if (!chatLogElem) {
				return null;
			}

			const messageElem = chatLogElem.querySelector('#chatMessage-' + messageId);
			if (!messageElem) {
				return null;
			}

			messageElem.remove();

			if (!chatLogElem.querySelector('[id^="chatMessage"]')) {
				chatLogElem.innerHTML = this.chatbox.locale.noMessages;
			}

		}

	}

	listenChanges() {

		const chatLogElem = document.querySelector(this.chatbox.elements.log);
		if (!chatLogElem) {
			return null;
		}

		setInterval(async () => {

			if (this.busy) {
				return null;
			}

			this.busy = true;
			const data = this.data.map((item) => item.id);

			let response = await fetch(this.endpoint, {
				method: 'post',
				body: JSON.stringify({
					action: 'getChanges',
					data: data
				})
			});

			response = await response.json();
			if (!response.success) {
				return null;
			}

			if (response.data.newMessages.length > 0) {
				this.playSound('new_message');
				this.addMessages(response.data.newMessages);
			}

			if (response.data.removedMessages.length > 0) {
				this.removeMessages(response.data.removedMessages);
			}

			this.busy = false;

		}, this.delay);

	}

	decodeVariables(string, variables) {
	
		if (typeof variables === 'object') {
			for (let [key, value] of Object.entries(variables)) {
				string = string.split(`{${key}}`).join(value);
			}
		}
	
		return string;
	
	}

	playSound(sound) {

		if (!this.chatbox.soundsEnabled) {
			return false;
		}

		const audio = new Audio(`${siteURL}modules/Chatbox/assets/sounds/${sound}.wav`);
		audio.play().then(() => {}).catch(() => {});

	}

}