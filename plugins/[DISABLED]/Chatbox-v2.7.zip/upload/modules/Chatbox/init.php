<?php

/**
 *	CHATBOX MODULE
 *	By Xemah | https://xemah.com
 *
**/

require(__DIR__ . '/module.php');
$module = new ChatboxModule($pages, $queries);